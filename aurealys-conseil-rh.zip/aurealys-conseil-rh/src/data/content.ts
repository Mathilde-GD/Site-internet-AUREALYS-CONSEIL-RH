export interface ServicePillar {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  features: string[];
  deliverables: string[];
  forWho: string;
  badge: string;
}

export interface PricingPackage {
  id: string;
  name: string;
  tagline: string;
  popular?: boolean;
  idealFor: string;
  features: string[];
  ctaLabel: string;
  type: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  sector: string;
  location: string;
  quote: string;
  metric: string;
}

export interface AuditQuestion {
  id: number;
  question: string;
  context: string;
  options: {
    label: string;
    score: number; // 0 to 20
    feedback: string;
  }[];
}

export interface PodcastEpisode {
  id: string;
  title: string;
  duration: string;
  category: string;
  description: string;
  takeaway: string;
  youtubeUrl: string;
  isLatest?: boolean;
}

export interface JourneyStep {
  step: string;
  title: string;
  subtitle: string;
  description: string;
  deliverable: string;
  duration: string;
}

export const COMPANY_INFO = {
  name: "Auréalys Conseil RH",
  legalName: "AUREALYS CONSEIL RH",
  founder: "Mathilde Galland",
  title: "Experte RH & Juriste en Droit Social",
  experienceYears: "8+",
  specialty: "Entreprises Multi-Sites & Multi-Conventionnelles",
  phone: "07 63 43 43 78",
  phoneDisplay: "07 63 43 43 78",
  phoneRaw: "+33763434378",
  email: "contact@aurealysconseilrh.fr",
  address: "270 allée des Lilas, 01150 Saint-Vulbas",
  region: "Parc Industriel de la Plaine de l'Ain (PIPA) · Auvergne-Rhône-Alpes",
  badge: "Membre du réseau AURA PEP'S & PIPA",
  hours: "Du lundi au vendredi de 8h30 à 18h30",
  youtubeChannelUrl: "https://www.youtube.com/@aurealysconseilrh",
  podcastName: "Le Bureau et la Loi",
  podcastTagline: "Le podcast du droit social et des RH pragmatiques pour chefs d'entreprise et managers de TPE/PME.",
  instagramUrl: "https://www.instagram.com/aurealysconseilrh",
};

export const CUSTOMER_JOURNEY: JourneyStep[] = [
  {
    step: "01",
    title: "Diagnostic RH offert",
    subtitle: "30 minutes d'échange stratégique",
    description: "Nous faisons le point sur votre situation actuelle (litige en cours, contrats à auditer, gestion multi-sites ou multi-CCN, besoin de présence RH). Vous repartez avec une première orientation juridique concrète, sans aucun engagement.",
    deliverable: "Analyse préalable de vos risques & premier avis juridique",
    duration: "30 minutes (Visio ou Téléphone)"
  },
  {
    step: "02",
    title: "Proposition claire & sur-mesure",
    subtitle: "Pas de mauvaise surprise",
    description: "Sous 24 à 48h, nous validons ensemble la formule la plus adaptée à vos effectifs et vos enjeux : Pack Essentiel, Pack Standard ou Pack Pretium.",
    deliverable: "Devis transparent, calendrier d'intervention et engagements précis",
    duration: "Sous 24h à 48h"
  },
  {
    step: "03",
    title: "Action opérationnelle & sécurisation",
    subtitle: "Du concret sur le terrain",
    description: "Nous prenons les choses en main : rédaction et validation d'actes, gestion des procédures sensibles, mise aux normes réglementaires ou présence dans vos locaux pour accompagner vos équipes sur vos différents sites.",
    deliverable: "Documents opposables, procédures blindées et dialogue social apaisé",
    duration: "Selon la formule choisie"
  },
  {
    step: "04",
    title: "Suivi pérenne & hotline dirigeant",
    subtitle: "Votre esprit libéré",
    description: "Vous n'êtes plus jamais seul face à un doute en droit du travail. Un simple appel ou email à Mathilde vous apporte une réponse rapide, pragmatique et juridiquement irréprochable.",
    deliverable: "Accès prioritaire à votre juriste dédiée & veille conventionnelle continue",
    duration: "Accompagnement continu"
  }
];

export const PODCAST_EPISODES: PodcastEpisode[] = [
  {
    id: "ep-latest-performance",
    title: "Le contentieux qui naît d'une performance jamais formalisée",
    duration: "19 min",
    category: "Dernier Épisode · Traçabilité Managériale",
    description: "Décryptage d'un cas réel : comment une baisse de performance ou un comportement inadapté jamais formalisé par écrit peut se retourner contre l'employeur lors d'une rupture. Points de vigilance indispensables pour les dirigeants de 1 à 89 salariés.",
    takeaway: "En droit social, ce qui n'est pas tracé et factuellement documenté n'existe pas aux yeux des prud'hommes. L'écrit bienveillant et régulier est votre meilleure protection.",
    youtubeUrl: "https://www.youtube.com/@aurealysconseilrh",
    isLatest: true
  },
  {
    id: "ep-1",
    title: "Licencier un salarié : une décision qui ne s'improvise pas",
    duration: "18 min",
    category: "Procédures de rupture",
    description: "Découvrez les réflexes indispensables avant d'envisager la rupture d'un contrat de travail. Comment qualifier les faits, respecter scrupuleusement les délais et éviter les écueils les plus fréquents devant le Conseil de Prud'hommes.",
    takeaway: "Une procédure préparée avec rigueur réduit de 95% le risque de contentieux.",
    youtubeUrl: "https://www.youtube.com/@aurealysconseilrh"
  },
  {
    id: "ep-2",
    title: "Les preuves managériales indispensables en droit social",
    duration: "14 min",
    category: "Sécurisation managériale",
    description: "Pourquoi la phrase 'tout le monde le sait' ne vaut rien en droit du travail. Comment instaurer une traçabilité managériale saine, bienveillante mais juridiquement irréfutable au quotidien sans alourdir vos journées.",
    takeaway: "Seuls les faits précis, datés et formalisés protègent l'employeur.",
    youtubeUrl: "https://www.youtube.com/@aurealysconseilrh"
  },
  {
    id: "ep-3",
    title: "Sanctions disciplinaires : de l'avertissement à la faute grave",
    duration: "16 min",
    category: "Discipline & Gestion des conflits",
    description: "Comment choisir la sanction proportionnée sans dépasser le délai de prescription de 2 mois ? Revue des pièges courants entre mise à pied conservatoire et disciplinaire, et les formulations qui font toute la différence.",
    takeaway: "La proportionnalité et la rapidité de réaction sont les clés de la validité de la sanction.",
    youtubeUrl: "https://www.youtube.com/@aurealysconseilrh"
  },
  {
    id: "ep-4",
    title: "Médecine du travail & inaptitude : désamorcer les pièges coûteux",
    duration: "21 min",
    category: "Santé au travail & Risques",
    description: "Quand faut-il impérativement solliciter le médecin du travail ? Comment réagir face à un avis d'inaptitude, respecter l'obligation de recherche de reclassement et consulter le CSE dans les règles de l'art.",
    takeaway: "La consultation préalable du CSE et la traçabilité des recherches de postes évitent la requalification.",
    youtubeUrl: "https://www.youtube.com/@aurealysconseilrh"
  }
];

export const DUAL_EXPERTISE_POINTS = [
  {
    title: "La Rigueur du Droit Social",
    subtitle: "Votre bouclier juridique",
    description: "Plus de 8 ans de pratique en droit du travail acquise au sein d'entreprises multi-sites et multi-conventionnelles. Chaque acte, contrat ou procédure est conforme au Code du travail, à vos différentes conventions collectives applicables et à la jurisprudence la plus récente.",
    points: [
      "Gestion experte des environnements multi-conventions collectives (CCN)",
      "Harmonisation des statuts sociaux et accords d'entreprise multi-sites",
      "Sécurisation absolue des ruptures, sanctions et contentieux",
      "Audits de conformité réglementaire (DUERP, affichages, CSE, temps de travail)"
    ]
  },
  {
    title: "L'Agilité du RH Opérationnel",
    subtitle: "Votre bras droit de terrain",
    description: "Le droit n'est rien sans la compréhension concrète des ateliers, entrepôts, agences et bureaux. Nous intervenons aux côtés des dirigeants et managers distants pour désamorcer les tensions, structurer les recrutements et fidéliser vos talents.",
    points: [
      "Pilotage RH d'équipes réparties sur plusieurs sites géographiques",
      "Animation des entretiens annuels et professionnels obligatoires",
      "Processus d'onboarding et intégration réussie des nouveaux arrivants",
      "DRH à temps partagé directement dans vos locaux et auprès de vos managers"
    ]
  }
];

export const SERVICES: ServicePillar[] = [
  {
    id: "securisation-juridique",
    number: "01",
    title: "Sécurisation Juridique & Droit Social",
    subtitle: "Protégez votre entreprise face aux risques prud'homaux et réglementaires",
    badge: "Expertise Droit Social & Multi-CCN",
    description: "Le droit du travail français est dense et particulièrement exigeant lorsque plusieurs conventions collectives coexistent. Nous sécurisons chaque acte RH de la rédaction du contrat initial jusqu'à la fin de la relation de travail.",
    features: [
      "Rédaction et mise à jour des contrats de travail (CDI, CDD, temps partiel, forfait jours)",
      "Gestion des clauses sensibles : non-concurrence, mobilité géographique, confidentialité, télétravail",
      "Sécurisation des procédures disciplinaires : avertissements, convocations, sanctions",
      "Gestion des départs : ruptures conventionnelles, accords transactionnels, licenciements",
      "Application stricte de vos conventions collectives (CCN) et conformité légale",
    ],
    deliverables: [
      "Modèles de contrats personnalisés et opposables",
      "Calendrier de procédure avec respect scrupuleux des délais",
      "Dossier juridique complet prêt en cas de contrôle ou litige"
    ],
    forWho: "Dirigeants qui souhaitent prendre des décisions RH sereines sans craindre le conseil de prud'hommes."
  },
  {
    id: "temps-partage",
    number: "02",
    title: "DRH & Responsable RH à Temps Partagé",
    subtitle: "L'expertise d'un cadre RH chevronné, adaptée au format de votre PME",
    badge: "RH Opérationnel Multi-Sites",
    description: "Bénéficiez d'une direction des ressources humaines opérationnelle sans alourdir votre masse salariale fixe. Une présence régulière (1 à 4 jours par mois) directement dans vos différents sites ou à distance.",
    features: [
      "Pilotage opérationnel de votre politique RH au plus près de vos équipes et managers",
      "Interlocuteur direct des salariés pour désamorcer les tensions et fidéliser",
      "Animation du dialogue social et relations avec les représentants du personnel (CSE)",
      "Mise en place des processus RH : intégration, gestion des temps, entretiens annuels",
      "Coordination fluide entre siège et implantations secondaires",
    ],
    deliverables: [
      "Permanence RH dédiée (sur site et/ou hotline dirigeant)",
      "Tableau de bord de pilotage RH mensuel",
      "Feuille de route stratégique RH alignée sur vos objectifs business"
    ],
    forWho: "TPE et PME de 10 à 100 salariés avec un ou plusieurs sites, ne justifiant pas d'un poste RH plein temps."
  },
  {
    id: "audit-conformite",
    number: "03",
    title: "Audit de Conformité RH & CSE",
    subtitle: "Identifiez vos failles cachées avant l'inspection du travail ou l'URSSAF",
    badge: "Conformité Légale & CCN",
    description: "Une radiographie complète et bienveillante de vos pratiques RH pour mesurer votre niveau de conformité légale et conventionnelle, particulièrement utile en cas de multiplicité de conventions ou de reprise de structure.",
    features: [
      "Vérification des affichages obligatoires et registres réglementaires (registre unique)",
      "Contrôle de la mise à jour du DUERP (Document Unique d'Évaluation des Risques)",
      "Audit des contrats, avenants, durées du travail et forfaits jours en vigueur",
      "Vérification des obligations de formation et des entretiens professionnels (tous les 2 ans)",
      "Conformité du Comité Social et Économique (CSE) et des procès-verbaux",
    ],
    deliverables: [
      "Rapport d'audit exhaustif avec code couleur par niveau de criticité",
      "Plan d'action correctif chiffré et hiérarchisé",
      "Kit de modèles et documents réglementaires personnalisés"
    ],
    forWho: "Entreprises multi-sites, croissance externe, reprise de société ou souhait de faire un bilan complet."
  },
  {
    id: "recrutement-talents",
    number: "04",
    title: "Recrutement & Marque Employeur",
    subtitle: "Attirez les bons profils et sécurisez leur intégration durable",
    badge: "Développement des Talents",
    description: "Du sourcing des talents à la validation de la période d'essai, nous vous accompagnons pour attirer des collaborateurs motivés et fidéliser vos équipes clés.",
    features: [
      "Définition précise du besoin, fiche de poste et grille de rémunération",
      "Rédaction d'annonces attractives valorisant votre culture d'entreprise",
      "Présélection rigoureuse, entretiens de qualification et prise de références",
      "Parcours d'onboarding sur-mesure pour maximiser l'engagement dès le jour J",
      "Accompagnement managérial et validation sereine des périodes d'essai",
    ],
    deliverables: [
      "Dossiers de candidature détaillés avec synthèse d'évaluation",
      "Livret d'accueil et check-list d'intégration nouveaux arrivants",
      "Guide d'entretien d'évaluation pour le manager"
    ],
    forWho: "Dirigeants confrontés à des tensions de recrutement ou souhaitant structurer l'accueil de leurs collaborateurs."
  }
];

// The 3 exact offers requested by Mathilde: Le Pack Essentiel, Le Pack Pilotage, Le Pack Premium
export const PACKAGES: PricingPackage[] = [
  {
    id: "pack-essentiel",
    name: "Le Pack Essentiel",
    tagline: "Sécurisez les fondations juridiques et bénéficiez d'une réponse rapide à chaque doute",
    popular: false,
    idealFor: "TPE de 1 à 12 salariés souhaitant un filet de sécurité juridique sans contrainte",
    type: "Abonnement mensuel souple & réactif",
    features: [
      "Hotline dirigeant dédiée avec Mathilde Galland (téléphone & email sous 24h ouvrées)",
      "Relecture et validation de vos contrats types (CDI, CDD) et avenants récurrents",
      "Conseils personnalisés sur l'application de votre convention collective (CCN)",
      "Aide à la qualification juridique des incidents et premiers réflexes disciplinaires",
      "Accès aux modèles types de documents RH certifiés (convocations, avenants, attestations)",
      "Veille juridique et sociale continue sur les évolutions légales impactant votre secteur"
    ],
    ctaLabel: "Choisir le Pack Essentiel"
  },
  {
    id: "pack-pilotage",
    name: "Le Pack Pilotage",
    tagline: "L'accompagnement RH & juridique complet au quotidien pour diriger l'esprit tranquille",
    popular: true,
    idealFor: "PME de 10 à 35 salariés sans service RH interne ou ayant 1 à 2 sites d'activité",
    type: "Formule la plus plébiscitée par les dirigeants",
    features: [
      "Tout le Pack Essentiel avec ligne prioritaire directe",
      "Prise en charge intégrale des procédures de rupture (rupture conventionnelle, licenciement, transaction)",
      "Rédaction de l'ensemble de vos actes disciplinaires (avertissements, mises à pied, notifications)",
      "Sécurisation des clauses spécifiques : non-concurrence, forfait jours, télétravail, mobilité",
      "Suivi des échéances obligatoires : entretiens professionnels, mise à jour DUERP, affichages",
      "1 point mensuel de pilotage et cadrage stratégique RH avec la direction générale"
    ],
    ctaLabel: "Choisir le Pack Pilotage"
  },
  {
    id: "pack-premium",
    name: "Le Pack Premium",
    tagline: "L'excellence RH sur-mesure : votre véritable DRH externalisée de terrain",
    popular: false,
    idealFor: "Entreprises multi-sites ou structures de 25 à 80+ salariés aux enjeux complexes",
    type: "Direction RH externalisée & Temps partagé",
    features: [
      "Tout le Pack Pilotage avec réactivité d'urgence sous 24h ouvrées",
      "Présence opérationnelle régulière dans vos locaux ou sur vos différents sites (temps partagé dédié)",
      "Harmonisation sociale multi-sites et multi-conventionnelle (CCN multiples)",
      "Animation des relations avec le CSE et accompagnement dans le dialogue social",
      "Structuration globale : fiches de poste, grilles salariales, plan de compétences et entretiens",
      "Conduite et médiation des entretiens managériaux sensibles et départs stratégiques",
      "Interlocutrice RH directe et bienveillante pour vos managers et collaborateurs"
    ],
    ctaLabel: "Choisir le Pack Premium"
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "1",
    name: "Laurent V.",
    role: "Directeur Général",
    company: "PME Métallurgie multi-sites (38 salariés)",
    sector: "Industrie mécanique & métallurgie",
    location: "Parc Industriel de la Plaine de l'Ain",
    quote: "Avec 2 sites de production et des conventions collectives différentes, nous avons opté pour le Pack Premium. Mathilde a harmonisé nos pratiques, sécurisé nos contrats et désamorcé un litige prud'homal qui nous menaçait. Sa connaissance des environnements multi-sites fait toute la différence.",
    metric: "0 contentieux en 2 ans d'accompagnement"
  },
  {
    id: "2",
    name: "Sophie M.",
    role: "Fondatrice & Dirigeante",
    company: "Société de Logistique & Distribution (22 salariés)",
    sector: "Transport & Logistique",
    location: "Saint-Vulbas",
    quote: "Le Pack Pilotage nous a apporté une sérénité totale. Dès que j'ai une question sur une rupture ou une sanction, j'appelle Mathilde : elle me prépare les documents en 24h, conformes à notre convention collective. C'est le bras droit indispensable de tout dirigeant.",
    metric: "-40% de turnover sur l'équipe terrain"
  },
  {
    id: "3",
    name: "Alexandre D.",
    role: "Président",
    company: "Agence Digitale & E-commerce (14 salariés)",
    sector: "Numérique & Services",
    location: "Lyon Métropole",
    quote: "Avec le Pack Essentiel, nous avons enfin des contrats de travail blindés et une hotline disponible dès le moindre doute. Fini les formulaires trouvés au hasard sur internet qui peuvent coûter une fortune en cas de prud'hommes.",
    metric: "+5h par semaine libérées pour le dirigeant"
  }
];

export const AUDIT_QUESTIONS: AuditQuestion[] = [
  {
    id: 1,
    question: "Vos contrats de travail et avenants sont-ils révisés régulièrement ?",
    context: "La jurisprudence et les conventions collectives évoluent constamment. Une clause obsolète peut être déclarée nulle ou requalifiée.",
    options: [
      {
        label: "Oui, audités et mis à jour il y a moins de 12 mois par un expert",
        score: 20,
        feedback: "Excellente pratique : vos modèles intègrent les dernières évolutions législatives."
      },
      {
        label: "Nous utilisons d'anciens modèles adaptés en interne au fil du temps",
        score: 10,
        feedback: "Attention : les clauses de forfait jours, non-concurrence ou télétravail requièrent une rédaction très stricte pour être valables."
      },
      {
        label: "Non, nous n'avons jamais fait relire nos contrats par un juriste",
        score: 0,
        feedback: "Zone à haut risque : un simple manquement formel peut coûter plusieurs mois de salaire devant les prud'hommes."
      }
    ]
  },
  {
    id: 2,
    question: "Votre Document Unique d'Évaluation des Risques (DUERP) est-il à jour ?",
    context: "Obligatoire dès le 1er salarié, il doit être actualisé annuellement et conservé pendant 40 ans sous peine de sanctions pénales.",
    options: [
      {
        label: "Oui, à jour avec le plan d'actions associé et communiqué aux salariés",
        score: 20,
        feedback: "Parfait : vous respectez l'obligation de sécurité de résultat de l'employeur."
      },
      {
        label: "Il existe mais n'a pas été révisé depuis plus de 2 ans",
        score: 8,
        feedback: "Vigilance : l'inspection du travail ou la CARSAT peut relever une infraction lors d'un contrôle."
      },
      {
        label: "Non, nous n'avons pas encore rédigé de DUERP",
        score: 0,
        feedback: "Urgence légale : en cas d'accident du travail, la faute inexcusable de l'employeur peut être engagée automatiquement."
      }
    ]
  },
  {
    id: 3,
    question: "Avez-vous réalisé les entretiens professionnels obligatoires ?",
    context: "L'entretien professionnel doit avoir lieu tous les 2 ans avec un état des lieux récapitulatif à 6 ans (sanction : abondement CPF de 3 000 € par salarié pour les entreprises de 50+).",
    options: [
      {
        label: "Oui, planifiés tous les 2 ans avec émargement et compte-rendu formalisé",
        score: 20,
        feedback: "Très bien : la gestion des compétences et la conformité légale sont assurées."
      },
      {
        label: "Nous faisons des entretiens annuels d'évaluation mais sans distinguer le volet professionnel",
        score: 10,
        feedback: "Attention fréquente : l'entretien annuel de performance ne remplace pas juridiquement l'entretien professionnel obligatoire."
      },
      {
        label: "Non, aucun entretien n'est formalisé à ce jour",
        score: 0,
        feedback: "Risque de non-conformité et de démotivation des collaborateurs par manque de visibilité."
      }
    ]
  },
  {
    id: 4,
    question: "Comment gérez-vous une baisse de performance, une sanction ou un départ ?",
    context: "L'absence d'écrits et de traçabilité factuelle rend quasi impossible la justification d'un licenciement ou d'un départ devant les prud'hommes.",
    options: [
      {
        label: "Chaque dossier est validé et piloté par une experte en droit social avec traçabilité",
        score: 20,
        feedback: "Sécurité maximale : vous minimisez à 0% le risque de vice de forme."
      },
      {
        label: "Nous réagissons tardivement quand la situation devient intenable",
        score: 5,
        feedback: "Risque très élevé : le manque d'écrits préalables affaiblit considérablement la position de l'employeur."
      },
      {
        label: "Nous téléchargeons des formulaires et modèles génériques sur internet",
        score: 2,
        feedback: "Les modèles génériques ne protègent pas contre les clauses conventionnelles spécifiques."
      }
    ]
  },
  {
    id: 5,
    question: "Vos affichages obligatoires et le registre unique du personnel sont-ils conformes ?",
    context: "Plus de 15 mentions doivent être affichées ou diffusées de façon accessible (harcèlement, égalité F/H, inspection, médecine du travail).",
    options: [
      {
        label: "Oui, panneau d'affichage à jour avec coordonnées complètes et registre tenu",
        score: 20,
        feedback: "Conformité administrative sans faille."
      },
      {
        label: "Partiellement : quelques documents sont affichés mais sans certitude d'exhaustivité",
        score: 10,
        feedback: "Quelques ajustements rapides vous permettront d'être 100% en règle."
      },
      {
        label: "Non, rien n'est affiché dans nos locaux",
        score: 0,
        feedback: "Sanction immédiate possible de 4ème et 5ème classe en cas de visite inopinée de l'inspection du travail."
      }
    ]
  }
];

export const FAQS = [
  {
    question: "Quelle est la différence entre le Pack Essentiel, le Pack Pilotage et le Pack Premium ?",
    answer: "Le Pack Essentiel sécurise les bases juridiques et met à votre disposition une hotline de réponse sous 24h. Le Pack Pilotage (le plus choisi) prend en charge l'ensemble de vos procédures de rupture, vos sanctions disciplinaires et le suivi de vos obligations légales. Le Pack Premium inclut en plus une présence physique en temps partagé dans vos locaux, idéale pour les entreprises multi-sites et les structures de plus de 25 salariés."
  },
  {
    question: "Pourquoi faire appel à un cabinet externe plutôt que recruter un RH en interne ?",
    answer: "Pour une TPE ou PME de moins de 50 salariés, recruter un Responsable RH à temps plein représente un coût fixe annuel important (salaire, charges, équipement). Avec Auréalys Conseil RH, vous bénéficiez de l'expertise pointue d'une juriste et experte RH de plus de 8 ans d'expérience pour une fraction du coût, avec une flexibilité totale selon votre volume de travail."
  },
  {
    question: "Quelle est votre valeur ajoutée sur les entreprises multi-sites ou multi-conventionnelles ?",
    answer: "Gérer plusieurs conventions collectives (ex. Métallurgie, Syntec, Transport, BTP) ou plusieurs établissements secondaires demande une rigueur juridique extrême pour éviter les discriminations de traitement, les erreurs de classification ou les clauses de mobilité inopposables. Mathilde a développé son expertise principalement dans ces contextes complexes."
  },
  {
    question: "Que se passe-t-il si j'ai une situation conflictuelle urgente avec un salarié ?",
    answer: "Dans le cadre de nos packs d'accompagnement ou d'une mission ponctuelle, nous intervenons sous 24 à 48 heures. Nous analysons immédiatement les faits, qualifions juridiquement la situation et vous fournissons la stratégie adéquate (mise à pied conservatoire, convocation, protocole de négociation) afin de désamorcer le conflit et protéger l'entreprise."
  },
  {
    question: "Comment se déroule le premier rendez-vous de diagnostic ?",
    answer: "Le premier échange de 30 minutes est totalement offert et sans engagement. Il se déroule par téléphone ou en visioconférence. Nous faisons le point sur votre organisation, vos problématiques actuelles et vos effectifs afin de vous orienter vers le pack le plus adapté (Essentiel, Standard ou Pretium)."
  },
  {
    question: "Travaillez-vous en collaboration avec notre expert-comptable ou notre avocat ?",
    answer: "Absolument. Nous intervenons en parfaite synergie avec votre expert-comptable (qui gère la paie et les déclarations sociales) et vos conseils juridiques. Nous sommes le relais opérationnel et de terrain qui prépare les données fiables, rédige les clauses sur-mesure et accompagne les managers au quotidien."
  }
];
