import React, { useState } from 'react';
import { COMPANY_INFO } from '../data/content';
import { Youtube, Headphones, Phone, Mail, MapPin, Scale, ShieldCheck, FileText } from 'lucide-react';
import { LegalModal } from './LegalModal';

interface FooterProps {
  onOpenBooking: () => void;
  onOpenLegal?: (tab: 'mentions' | 'cgv' | 'rgpd') => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking }) => {
  const [legalModalOpen, setLegalModalOpen] = useState(false);
  const [selectedLegalTab, setSelectedLegalTab] = useState<'mentions' | 'cgv' | 'rgpd'>('mentions');

  const openLegal = (tab: 'mentions' | 'cgv' | 'rgpd') => {
    setSelectedLegalTab(tab);
    setLegalModalOpen(true);
  };

  return (
    <footer className="bg-slate-950 text-slate-400 py-16 border-t border-slate-900 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-slate-900">
          
          {/* Brand & Mission (4 cols) */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg overflow-hidden border border-amber-500/40 bg-[#0C1527] shadow-sm shrink-0 relative">
                <img
                  src="/src/assets/images/aurealys_logo_gold_1792406640670.jpg"
                  alt="Logo officiel Auréalys Conseil RH"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover scale-155 -translate-y-1"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-base font-extrabold text-white tracking-[0.06em] font-display uppercase leading-tight">
                  Auréalys
                </span>
                <span className="text-[10px] text-amber-400 font-bold tracking-[0.2em] uppercase leading-tight">
                  Conseil RH
                </span>
              </div>
            </div>
            
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Cabinet de conseil en ressources humaines & droit social pour dirigeants de TPE et PME. Externalisation RH, DRH à temps partagé et conformité juridique par Mathilde Galland.
            </p>

            <div className="text-[11px] text-slate-500">
              <span>{COMPANY_INFO.badge}</span>
            </div>
          </div>

          {/* Quick Links (3 cols) */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-white block">
              Nos Packs & Formules
            </span>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#formules" className="hover:text-white transition-colors">
                  Le Pack Essentiel
                </a>
              </li>
              <li>
                <a href="#formules" className="hover:text-white transition-colors text-amber-400 font-semibold">
                  Le Pack Pilotage (Plébiscité)
                </a>
              </li>
              <li>
                <a href="#formules" className="hover:text-white transition-colors">
                  Le Pack Premium (Multi-Sites & DRH)
                </a>
              </li>
              <li>
                <a href="#expertise" className="hover:text-white transition-colors">
                  Double Expertise Droit & RH
                </a>
              </li>
              <li>
                <a href="#parcours" className="hover:text-white transition-colors">
                  Parcours Client en 4 Étapes
                </a>
              </li>
              <li>
                <a href="#audit-express" className="hover:text-white transition-colors">
                  Auto-Diagnostic Risques RH
                </a>
              </li>
            </ul>
          </div>

          {/* Media & Podcast (2 cols) */}
          <div className="md:col-span-2 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-white block">
              Contenus & Médias
            </span>
            <ul className="space-y-2 text-xs">
              <li>
                <a 
                  href="#podcast" 
                  className="hover:text-white transition-colors flex items-center gap-1.5 text-amber-400"
                >
                  <Headphones className="w-3.5 h-3.5" />
                  <span>Podcast Le Bureau & la Loi</span>
                </a>
              </li>
              <li>
                <a 
                  href={COMPANY_INFO.youtubeChannelUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <Youtube className="w-3.5 h-3.5 text-red-500" />
                  <span>Chaîne YouTube</span>
                </a>
              </li>
              <li>
                <button 
                  onClick={onOpenBooking}
                  className="text-white font-semibold hover:underline cursor-pointer pt-2 block"
                >
                  &rarr; Réserver un diagnostic
                </button>
              </li>
            </ul>
          </div>

          {/* Direct Coordinates (3 cols) */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-white block">
              Contact & Accès
            </span>
            <div className="space-y-2 text-xs text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                <span>{COMPANY_INFO.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <a href={`tel:${COMPANY_INFO.phoneRaw}`} className="hover:text-white transition-colors">
                  {COMPANY_INFO.phoneDisplay}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <a href={`mailto:${COMPANY_INFO.email}`} className="hover:text-white transition-colors">
                  {COMPANY_INFO.email}
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright, CGV, Mentions Légales & RGPD */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} {COMPANY_INFO.legalName}. Tous droits réservés.
          </div>
          
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 justify-center">
            <button
              onClick={() => openLegal('mentions')}
              className="hover:text-slate-300 transition-colors underline cursor-pointer"
            >
              Mentions Légales
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => openLegal('cgv')}
              className="hover:text-amber-400 transition-colors font-medium underline cursor-pointer flex items-center gap-1"
            >
              <Scale className="w-3 h-3" />
              <span>Conditions Générales de Vente (CGV)</span>
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => openLegal('rgpd')}
              className="hover:text-slate-300 transition-colors underline cursor-pointer flex items-center gap-1"
            >
              <ShieldCheck className="w-3 h-3" />
              <span>Données & RGPD</span>
            </button>
            <span aria-hidden="true">·</span>
            <span>Saint-Vulbas (Ain) · France</span>
          </div>
        </div>

      </div>

      {/* Legal & CGV Modal */}
      <LegalModal
        isOpen={legalModalOpen}
        onClose={() => setLegalModalOpen(false)}
        initialTab={selectedLegalTab}
      />
    </footer>
  );
};
