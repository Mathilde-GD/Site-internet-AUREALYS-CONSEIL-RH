import React from 'react';

interface AurealysLogoProps {
  variant?: 'full' | 'emblem' | 'horizontal';
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const AurealysLogo: React.FC<AurealysLogoProps> = ({
  variant = 'horizontal',
  className = '',
  size = 'md',
}) => {
  const logoSrc = "/src/assets/images/aurealys_logo_gold_1792406640670.jpg";

  if (variant === 'full') {
    const sizeClasses = {
      sm: 'w-24 h-24',
      md: 'w-36 h-36',
      lg: 'w-48 h-48',
      xl: 'w-64 h-64',
    };

    return (
      <div className={`relative rounded-xl overflow-hidden shadow-lg border border-neutral-800 bg-[#0C1527] ${sizeClasses[size]} ${className}`}>
        <img
          src={logoSrc}
          alt="Logo officiel Auréalys Conseil RH"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  if (variant === 'emblem') {
    const sizeClasses = {
      sm: 'w-8 h-8',
      md: 'w-10 h-10',
      lg: 'w-12 h-12',
      xl: 'w-16 h-16',
    };

    return (
      <div className={`relative rounded-lg overflow-hidden shadow-sm border border-amber-500/30 bg-[#0C1527] shrink-0 ${sizeClasses[size]} ${className}`}>
        <img
          src={logoSrc}
          alt="Emblème Auréalys Conseil RH"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover scale-150 -translate-y-1"
        />
      </div>
    );
  }

  // Variant: horizontal (perfect for TopBar Navbar & Footer Brand lockup)
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Golden A Emblem square */}
      <div className="w-10 h-10 rounded-lg overflow-hidden border border-amber-500/40 bg-[#0C1527] shadow-sm shrink-0 relative group">
        <img
          src={logoSrc}
          alt="Logo Auréalys"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover scale-155 -translate-y-1.5 transition-transform duration-300 group-hover:scale-165"
        />
      </div>

      {/* Brand typography */}
      <div className="flex flex-col">
        <span className="text-lg font-extrabold tracking-[0.08em] text-slate-900 font-display leading-tight uppercase">
          Auréalys
        </span>
        <span className="text-[10px] text-amber-900 font-bold tracking-[0.2em] uppercase leading-tight">
          Conseil RH
        </span>
      </div>
    </div>
  );
};
