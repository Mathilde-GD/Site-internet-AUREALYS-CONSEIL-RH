import React from 'react';
import { COMPANY_INFO } from '../data/content';
import { Award, BookOpen, MapPin, CheckCircle2, Calendar, Phone, Building2, Quote } from 'lucide-react';

interface AboutMathildeProps {
  onOpenBooking: () => void;
}

export const AboutMathilde: React.FC<AboutMathildeProps> = ({ onOpenBooking }) => {
  return (
    <section id="a-propos" className="py-20 bg-[#FAF9F5] border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Portrait & Credentials (5 cols) */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden border border-neutral-300 shadow-xl bg-white max-w-md mx-auto">
              
              <div className="aspect-[3/4] relative bg-neutral-100 overflow-hidden">
                <img
                  src="/src/assets/images/mathilde_galland_portrait_1792405341337.jpg"
                  alt="Mathilde Galland, fondatrice d'Auréalys Conseil RH et juriste en droit social"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
                
                {/* Overlay Name & Title */}
                <div className="absolute bottom-5 left-5 right-5 text-white">
                  <span className="text-xl font-bold font-display block">
                    {COMPANY_INFO.founder}
                  </span>
                  <span className="text-xs text-amber-300 font-medium tracking-wide">
                    {COMPANY_INFO.title}
                  </span>
                  <span className="text-[11px] text-slate-300 block mt-0.5">
                    +8 ans d'expérience · Multi-sites & Multi-CCN
                  </span>
                </div>
              </div>

              {/* Bottom Quick Contact Bar */}
              <div className="p-4 bg-white border-t border-neutral-200 flex flex-col gap-2.5 text-xs text-slate-700">
                <div className="flex items-center gap-2.5 pb-2 border-b border-neutral-100">
                  <div className="w-8 h-8 rounded-md overflow-hidden border border-amber-500/40 bg-[#0C1527] shadow-2xs shrink-0">
                    <img
                      src="/src/assets/images/aurealys_logo_gold_1792406640670.jpg"
                      alt="Logo Auréalys"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover scale-155 -translate-y-0.5"
                    />
                  </div>
                  <div className="flex flex-col">
                    <span className="font-bold text-slate-900 leading-tight">Auréalys Conseil RH</span>
                    <span className="text-[10px] text-slate-500 leading-tight">Cabinet certifié · Plaine de l'Ain (PIPA)</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  <span>{COMPANY_INFO.address}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  <span>{COMPANY_INFO.badge}</span>
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Bio & Philosophy (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase">
                <span>Fondatrice & Dirigeante</span>
                <span aria-hidden="true" className="text-slate-400">·</span>
                <span className="text-slate-500 font-normal normal-case">Une partenaire de confiance</span>
              </div>
              
              {/* Mathilde's authentic quote from her flyer */}
              <div className="relative pl-6 py-2 border-l-2 border-amber-600/60 my-2">
                <p className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight font-display italic leading-snug">
                  « Le droit du travail n’est pas réservé aux grands groupes. Ce n’est pas une question de taille. C’est une question de méthode. Sécuriser, ce n’est pas tout verrouiller. C’est poser des fondations silencieuses. »
                </p>
                <span className="text-xs font-semibold text-amber-900 block mt-2 not-italic">
                  — Mathilde Galland
                </span>
              </div>
            </div>

            <div className="space-y-4 text-sm sm:text-base text-slate-600 leading-relaxed">
              <p>
                Forte de <strong>plus de 8 ans d'expérience</strong> acquise principalement au sein d'<strong>entreprises multi-sites et multi-conventionnelles</strong>, j'ai fondé <strong>Auréalys Conseil RH</strong> pour répondre aux défis très concrets des dirigeants de TPE et PME.
              </p>
              <p>
                Quand une entreprise grandit, qu'elle ouvre plusieurs dépôts, ateliers ou agences, ou qu'elle applique plusieurs conventions collectives (CCN), les risques de non-conformité et d'incompréhension sociale se multiplient. Une mauvaise qualification, une clause de mobilité mal rédigée ou une performance dégradée jamais tracée par écrit peuvent coûter très cher devant les prud'hommes.
              </p>
              <p>
                Je me positionne à vos côtés comme votre <strong>bras droit RH et juridique</strong> : disponible au téléphone, réactive en cas d'urgence, et présente dans vos locaux pour instaurer un climat social serein et constructif.
              </p>
            </div>

            {/* Core Values */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-3.5 rounded-xl bg-white border border-neutral-200">
                <span className="text-xs font-bold text-slate-900 block mb-1 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-slate-700" />
                  Expertise Multi-Sites & Multi-CCN
                </span>
                <p className="text-xs text-slate-600 leading-snug">
                  Habituée aux contextes complexes où coexistent plusieurs établissements et conventions collectives différentes.
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-white border border-neutral-200">
                <span className="text-xs font-bold text-slate-900 block mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-slate-700" />
                  Réactivité absolue (24-48h)
                </span>
                <p className="text-xs text-slate-600 leading-snug">
                  Une ligne directe avec moi. Vous ne parlez pas à une plateforme anonyme mais à votre juriste attitrée.
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <button
                onClick={onOpenBooking}
                className="px-6 py-3 rounded-lg bg-slate-900 text-white text-xs sm:text-sm font-semibold hover:bg-slate-800 transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Prendre rendez-vous avec Mathilde</span>
              </button>
              <a
                href={`tel:${COMPANY_INFO.phoneRaw}`}
                className="px-5 py-3 rounded-lg bg-white border border-neutral-300 text-slate-800 text-xs sm:text-sm font-semibold hover:bg-neutral-50 transition-all flex items-center justify-center gap-2 shadow-2xs"
              >
                <Phone className="w-4 h-4 text-slate-600" />
                <span>Appeler le {COMPANY_INFO.phoneDisplay}</span>
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
