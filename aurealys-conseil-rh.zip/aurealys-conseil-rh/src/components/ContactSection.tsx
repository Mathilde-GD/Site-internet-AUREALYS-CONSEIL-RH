import React, { useState } from 'react';
import { COMPANY_INFO } from '../data/content';
import { Phone, Mail, MapPin, Send, CheckCircle2, Clock, Calendar, ExternalLink } from 'lucide-react';

interface ContactSectionProps {
  onOpenBooking: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenBooking }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};
    if (!formData.name) newErrors.name = "Votre nom est obligatoire";
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = "Email valide requis";
    if (!formData.message) newErrors.message = "Veuillez renseigner votre message";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Coordinates (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase">
                <span>Coordonnées Directes</span>
                <span aria-hidden="true" className="text-slate-400">·</span>
                <span className="text-slate-500 font-normal normal-case">Saint-Vulbas & Rhône-Alpes</span>
              </div>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight font-display">
                Discutons de vos besoins RH
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Une urgence contractuelle ? Un projet d'externalisation RH ? Mathilde Galland vous répond personnellement sous 24h ouvrées.
              </p>
            </div>

            {/* Direct Cards */}
            <div className="space-y-3 pt-2">
              <a
                href={`tel:${COMPANY_INFO.phoneRaw}`}
                className="p-4 rounded-xl border border-neutral-200 hover:border-slate-900 bg-[#FCFCFA] flex items-center gap-4 transition-all group block"
              >
                <div className="w-10 h-10 rounded-lg bg-slate-900 text-amber-300 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                    Téléphone Direct
                  </span>
                  <span className="text-base font-bold text-slate-900 font-display group-hover:text-amber-800 transition-colors">
                    {COMPANY_INFO.phoneDisplay}
                  </span>
                </div>
              </a>

              <a
                href={`mailto:${COMPANY_INFO.email}`}
                className="p-4 rounded-xl border border-neutral-200 hover:border-slate-900 bg-[#FCFCFA] flex items-center gap-4 transition-all group block"
              >
                <div className="w-10 h-10 rounded-lg bg-slate-900 text-amber-300 flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                    Email Professionnel
                  </span>
                  <span className="text-sm sm:text-base font-bold text-slate-900 font-display group-hover:text-amber-800 transition-colors break-all">
                    {COMPANY_INFO.email}
                  </span>
                </div>
              </a>

              <div className="p-4 rounded-xl border border-neutral-200 bg-[#FCFCFA] flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-slate-900 text-amber-300 flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                    Cabinet & Siège
                  </span>
                  <span className="text-sm font-bold text-slate-900 block font-display">
                    {COMPANY_INFO.address}
                  </span>
                  <span className="text-xs text-slate-500 block">
                    {COMPANY_INFO.region}
                  </span>
                  <a
                    href="https://maps.google.com/?q=270+allee+des+Lilas+01150+Saint-Vulbas"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-800 hover:underline pt-1"
                  >
                    <span>Voir sur Google Maps</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200/60 text-xs text-amber-950 flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-800 shrink-0" />
                <span>Horaires d'ouverture : {COMPANY_INFO.hours}</span>
              </div>
            </div>

            {/* Direct Booking Reminder */}
            <div className="pt-2">
              <button
                onClick={onOpenBooking}
                className="w-full py-3 px-4 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Calendar className="w-4 h-4" />
                <span>Vous préférez planifier un créneau ? Prendre RdV en 1 clic</span>
              </button>
            </div>
          </div>

          {/* Right Column: Contact Form (7 cols) */}
          <div className="lg:col-span-7 bg-[#FCFCFA] border border-neutral-200 rounded-2xl p-6 sm:p-8 shadow-xs">
            <h3 className="text-xl font-bold text-slate-900 font-display mb-2">
              Envoyer un message direct
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Remplissez ce formulaire court pour poser une question ou décrire votre situation en toute discrétion.
            </p>

            {!submitted ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Votre Nom & Prénom *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="ex. David Martin"
                      className={`w-full text-xs p-2.5 rounded-lg border bg-white focus:outline-none focus:ring-1 focus:ring-slate-900 ${
                        errors.name ? 'border-red-500' : 'border-neutral-200'
                      }`}
                    />
                    {errors.name && <span className="text-[10px] text-red-600 block mt-0.5">{errors.name}</span>}
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Entreprise / Structure
                    </label>
                    <input
                      type="text"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      placeholder="ex. Transports Martin SAS"
                      className="w-full text-xs p-2.5 rounded-lg border border-neutral-200 bg-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Email Professionnel *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="direction@entreprise.fr"
                      className={`w-full text-xs p-2.5 rounded-lg border bg-white focus:outline-none focus:ring-1 focus:ring-slate-900 ${
                        errors.email ? 'border-red-500' : 'border-neutral-200'
                      }`}
                    />
                    {errors.email && <span className="text-[10px] text-red-600 block mt-0.5">{errors.email}</span>}
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Numéro de Téléphone
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="06 XX XX XX XX"
                      className="w-full text-xs p-2.5 rounded-lg border border-neutral-200 bg-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Votre message ou situation RH *
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Expliquez-nous brièvement votre enjeu (rupture conventionnelle, mise à jour de contrats, DUERP, besoin de DRH à temps partagé...)"
                    className={`w-full text-xs p-2.5 rounded-lg border bg-white focus:outline-none focus:ring-1 focus:ring-slate-900 ${
                      errors.message ? 'border-red-500' : 'border-neutral-200'
                    }`}
                  />
                  {errors.message && <span className="text-[10px] text-red-600 block mt-0.5">{errors.message}</span>}
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-6 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Envoyer ma demande à Mathilde Galland</span>
                </button>
              </form>
            ) : (
              <div className="py-10 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-slate-900 font-display">
                  Message bien reçu !
                </h4>
                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  Merci {formData.name}, Mathilde Galland a bien reçu vos informations et reviendra vers vous sous 24 heures ouvrées.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({ name: '', email: '', phone: '', company: '', message: '' });
                  }}
                  className="text-xs text-slate-500 underline hover:text-slate-800 cursor-pointer pt-2"
                >
                  Envoyer un autre message
                </button>
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
};
