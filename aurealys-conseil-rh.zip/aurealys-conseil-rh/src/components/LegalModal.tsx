import React, { useState } from 'react';
import { X, ShieldCheck, FileText, Scale, Check } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'mentions' | 'cgv' | 'rgpd';
}

export const LegalModal: React.FC<LegalModalProps> = ({ isOpen, onClose, initialTab = 'mentions' }) => {
  const [activeTab, setActiveTab] = useState<'mentions' | 'cgv' | 'rgpd'>(initialTab);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-8 flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 flex items-center justify-between shrink-0">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 block mb-0.5">
              Informations Juridiques & Réglementaires
            </span>
            <h3 className="text-xl sm:text-2xl font-bold font-display">
              {COMPANY_INFO.name}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs Bar */}
        <div className="flex border-b border-neutral-200 bg-neutral-50 px-4 sm:px-6 pt-2 shrink-0 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('mentions')}
            className={`py-3 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'mentions'
                ? 'border-slate-900 text-slate-900 bg-white rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Mentions Légales
          </button>
          <button
            onClick={() => setActiveTab('cgv')}
            className={`py-3 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'cgv'
                ? 'border-slate-900 text-slate-900 bg-white rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Scale className="w-3.5 h-3.5" />
            <span>Conditions Générales de Vente (CGV)</span>
          </button>
          <button
            onClick={() => setActiveTab('rgpd')}
            className={`py-3 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'rgpd'
                ? 'border-slate-900 text-slate-900 bg-white rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Politique de Confidentialité (RGPD)</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto text-xs text-slate-700 space-y-6 leading-relaxed flex-1">
          
          {/* TAB 1: MENTIONS LÉGALES */}
          {activeTab === 'mentions' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-base font-bold text-slate-900 font-display mb-2">
                  1. Identification de l'Éditeur
                </h4>
                <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 space-y-1.5 text-xs">
                  <p><strong>Dénomination sociale :</strong> {COMPANY_INFO.legalName}</p>
                  <p><strong>Activité :</strong> Conseil pour les affaires et autres conseils de gestion, spécialisé en ressources humaines et droit social pour les entreprises</p>
                  <p><strong>Siège social :</strong> {COMPANY_INFO.address}</p>
                  <p><strong>Zone géographique :</strong> Parc Industriel de la Plaine de l'Ain (PIPA), Auvergne-Rhône-Alpes</p>
                  <p><strong>Téléphone direct :</strong> {COMPANY_INFO.phoneDisplay}</p>
                  <p><strong>Email de contact :</strong> {COMPANY_INFO.email}</p>
                  <p><strong>Directrice de la publication :</strong> Mathilde Galland, fondatrice et experte RH</p>
                </div>
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900 font-display mb-2">
                  2. Hébergement du Site
                </h4>
                <p>
                  Le présent site internet est hébergé sur des infrastructures d'hébergement sécurisées conformes aux normes européennes de protection des données (RGPD).
                </p>
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900 font-display mb-2">
                  3. Propriété Intellectuelle
                </h4>
                <p>
                  L'ensemble des éléments constituant le site {COMPANY_INFO.name} (notamment textes, articles, infographies, logotypes, charte graphique, épisodes du podcast « Le Bureau et la Loi », vidéos et éléments sonores) sont protégés par les lois françaises et internationales relatives à la propriété intellectuelle. Toute reproduction, représentation, modification ou diffusion, en tout ou partie, sans l'accord écrit préalable de Mathilde Galland est strictement interdite et sanctionnée au titre de la contrefaçon.
                </p>
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900 font-display mb-2">
                  4. Nature des Conseils & Absence de Plaidorie
                </h4>
                <p>
                  Les informations et conseils dispensés par Auréalys Conseil RH constituent des prestations de conseil opérationnel en ressources humaines et en droit social destinées aux employeurs. Auréalys Conseil RH n'exerce pas la profession d'avocat et ne procède à aucune représentation ni plaidoirie devant les juridictions de l'ordre judiciaire.
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: CGV (CONDITIONS GÉNÉRALES DE VENTE) */}
          {activeTab === 'cgv' && (
            <div className="space-y-6">
              
              <div className="p-4 bg-amber-50 rounded-xl border border-amber-200/80 text-amber-950 text-xs">
                <strong>Conditions Générales de Vente et de Prestations de Services d'Auréalys Conseil RH</strong><br />
                Applicables à l'ensemble des prestations de conseil RH, des forfaits d'intervention et des abonnements (Le Pack Essentiel, Le Pack Pilotage, Le Pack Premium) conclus entre {COMPANY_INFO.legalName} et ses clients professionnels (TPE, PME, ETI).
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 1 – Objet et Champ d'Application
                </h4>
                <p>
                  Les présentes Conditions Générales de Vente (CGV) régissent les relations contractuelles entre {COMPANY_INFO.legalName}, représentée par Mathilde Galland (ci-après dénommée « le Prestataire »), et toute personne morale ou entrepreneur individuel (ci-après dénommé « le Client ») souscrivant à ses prestations de conseil RH, droit social ou direction des ressources humaines en temps partagé.
                </p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 2 – Description des Offres & Formules
                </h4>
                <div className="space-y-2">
                  <p>Le Prestataire propose trois formules d'accompagnement récurrentes ainsi que des missions ponctuelles :</p>
                  <ul className="list-disc list-inside space-y-1.5 pl-2">
                    <li>
                      <strong>Le Pack Essentiel :</strong> Hotline dirigeant sous 24h ouvrées, relecture et validation des modèles types de contrats de travail et avenants courants, conseils sur l'application de la convention collective applicable et veille juridique.
                    </li>
                    <li>
                      <strong>Le Pack Pilotage :</strong> L'ensemble des prestations du Pack Essentiel avec ligne prioritaire directe, prise en charge intégrale des procédures de rupture (rupture conventionnelle, licenciement, accords transactionnels), rédaction des actes disciplinaires, sécurisation des clauses spécifiques et point de cadrage mensuel avec la direction.
                    </li>
                    <li>
                      <strong>Le Pack Premium :</strong> Direction RH externalisée haut de gamme incluant toutes les prestations du Pack Pilotage, avec présence opérationnelle sur site en temps partagé (1 à 2 jours par mois), harmonisation sociale en environnement multi-sites et multi-conventionnel, animation du dialogue social avec le CSE, et conduite des entretiens managériaux sensibles.
                    </li>
                    <li>
                      <strong>Missions Ponctuelles & Audits :</strong> Réalisation d'audits de conformité 360°, rédaction d'accords d'entreprise spécifiques ou gestion d'une urgence prud'homale ciblée.
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 3 – Commandes, Devis & Diagnostic Initial
                </h4>
                <p>
                  Toute souscription à un Pack (Essentiel, Pilotage, Premium) ou à une mission ponctuelle fait l'objet d'un devis ou d'une convention de prestations détaillée émise à l'issue du diagnostic initial offert de 30 minutes. L'accord devient définitif à réception par le Prestataire du devis ou de la convention dûment signée et paraphée par le Client.
                </p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 4 – Tarifs & Conditions de Règlement
                </h4>
                <p>
                  Les prix sont exprimés en euros hors taxes (HT) et sont majorés de la TVA au taux légal en vigueur. Pour les Packs (Essentiel, Standard, Pretium), la facturation intervient mensuellement par prélèvement ou virement bancaire au début de chaque période mensuelle. Les factures sont payables à réception ou à 30 jours nets selon les termes de la convention. Conformément aux dispositions légales, tout retard de paiement donne lieu de plein droit à l'application de pénalités de retard au taux directeur de la BCE majoré de 10 points et à une indemnité forfaitaire pour frais de recouvrement de 40 euros.
                </p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 5 – Obligation de Moyens & Responsabilité
                </h4>
                <p>
                  Le Prestataire est tenu à une <strong>obligation de moyens</strong> rigoureuse dans l'exécution de ses missions de conseil RH et de droit social. Le Prestataire apporte toute son expertise technique, sa diligence et sa compétence pour conseiller le Client conformément à la législation et à la jurisprudence en vigueur à la date de remise des actes. Le Prestataire ne saurait être tenu responsable des conséquences de déclarations incomplètes, inexactes ou tardives transmises par le Client.
                </p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 6 – Obligations du Client & Collaboration Loyale
                </h4>
                <p>
                  Pour permettre la bonne exécution des prestations, le Client s'engage à collaborer activement et de bonne foi avec le Prestataire, notamment en lui fournissant dans les délais requis l'ensemble des éléments factuels, contrats, avenants, échanges écrits et historiques nécessaires à l'analyse juridique et managériale de chaque dossier.
                </p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 7 – Confidentialité & Secret Professionnel
                </h4>
                <p>
                  Le Prestataire et le Client s'engagent réciproquement à la confidentialité la plus absolue sur l'ensemble des informations commerciales, financières, sociales, stratégiques et nominatives dont ils pourraient avoir connaissance au cours de l'exécution de la mission. Cet engagement demeure en vigueur sans limitation de durée après le terme des prestations.
                </p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 8 – Durée & Résiliation des Packs Mensuels
                </h4>
                <p>
                  Les abonnements mensuels (Pack Essentiel, Pack Standard, Pack Pretium) sont conclus pour une durée indéterminée ou annuelle avec tacite reconduction mensuelle, sauf stipulation contraire convenue dans la convention. Le Client peut résilier son pack par lettre recommandée avec accusé de réception ou email avec accusé de réception moyennant le respect d'un préavis d'un (1) mois avant l'échéance de la période en cours, sans pénalité.
                </p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Article 9 – Droit Applicable & Juridiction Compétente
                </h4>
                <p>
                  Les présentes CGV sont soumises au droit français. En cas de différend relatif à la validité, l'interprétation ou l'exécution des prestations, les parties s'engagent à rechercher prioritairement une solution amiable. À défaut d'accord amiable dans un délai de 30 jours, compétence exclusive est attribuée aux tribunaux compétents du ressort du siège social du Prestataire (Tribunal de Commerce compétent de l'Ain), même en cas d'appel en garantie ou de pluralité de défendeurs.
                </p>
              </div>

            </div>
          )}

          {/* TAB 3: RGPD & DONNÉES PERSONNELLES */}
          {activeTab === 'rgpd' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-base font-bold text-slate-900 font-display mb-2">
                  1. Respect du Règlement Général sur la Protection des Données (RGPD)
                </h4>
                <p>
                  {COMPANY_INFO.name} accorde une importance capitale à la protection de la vie privée et des données personnelles des dirigeants, salariés et prospects.
                </p>
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900 font-display mb-2">
                  2. Données collectées lors des prises de rendez-vous et formulaires
                </h4>
                <p>
                  Dans le cadre de l'utilisation du site et des demandes de diagnostic offert, les données recueillies se limitent aux informations strictement nécessaires au traitement de la demande : nom, prénom, nom de l'entreprise, effectif estimé, numéro de téléphone et adresse email professionnelle. Ces données sont utilisées exclusivement pour planifier l'échange, adresser la confirmation de rendez-vous et assurer le suivi de la relation commerciale.
                </p>
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900 font-display mb-2">
                  3. Non-cession des données
                </h4>
                <p>
                  En aucun cas vos données ne font l'objet d'une vente, d'une cession, d'une location ou d'une communication à des tiers à des fins publicitaires ou de prospection commerciale.
                </p>
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900 font-display mb-2">
                  4. Vos droits d'accès, de rectification et d'effacement
                </h4>
                <p>
                  Conformément au RGPD et à la loi Informatique et Libertés, vous disposez d'un droit d'accès, de rectification, de portabilité et d'effacement des données vous concernant. Pour exercer ces droits, il vous suffit d'adresser un email à <strong>{COMPANY_INFO.email}</strong> ou un courrier postal à l'attention de Mathilde Galland, {COMPANY_INFO.address}.
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-neutral-50 px-6 py-4 border-t border-neutral-200 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500">
            Dernière mise à jour : {new Date().getFullYear()} · {COMPANY_INFO.legalName}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            Fermer la fenêtre
          </button>
        </div>

      </div>
    </div>
  );
};
