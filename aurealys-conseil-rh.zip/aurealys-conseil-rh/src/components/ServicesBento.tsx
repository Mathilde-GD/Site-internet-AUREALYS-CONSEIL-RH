import React, { useState } from 'react';
import { SERVICES, ServicePillar } from '../data/content';
import { ShieldCheck, CheckCircle2, ArrowRight, FileText, ChevronRight } from 'lucide-react';

interface ServicesBentoProps {
  onOpenBooking: (serviceName?: string) => void;
}

export const ServicesBento: React.FC<ServicesBentoProps> = ({ onOpenBooking }) => {
  const [selectedPillar, setSelectedPillar] = useState<ServicePillar | null>(null);

  return (
    <section id="services" className="py-20 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase mb-2">
            <span>Accompagnements Sur-Mesure</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="text-slate-500 font-normal normal-case">TPE, PME & ETI Régionales</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display">
            4 Piliers Opérationnels pour Structurer vos Ressources Humaines
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            De la gestion de crise ponctuelle à la présence récurrente en temps partagé, choisissez l'intervention qui correspond exactement aux défis de votre entreprise.
          </p>
        </div>

        {/* 4-Pillar Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((s) => (
            <div
              key={s.id}
              className="rounded-2xl border border-neutral-200 bg-[#FCFCFA] p-8 flex flex-col justify-between hover:border-neutral-300 hover:shadow-sm transition-all"
            >
              <div className="space-y-4">
                
                {/* Header row with editorial number */}
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold font-mono text-slate-400">
                    {s.number}.
                  </span>
                  <span className="text-[11px] font-semibold text-amber-900 bg-amber-100/60 px-2.5 py-0.5 rounded">
                    {s.badge}
                  </span>
                </div>

                <div>
                  <h3 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
                    {s.title}
                  </h3>
                  <span className="text-xs font-medium text-slate-600 block mt-1">
                    {s.subtitle}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {s.description}
                </p>

                {/* Features list */}
                <div className="pt-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
                    Interventions types :
                  </span>
                  <ul className="space-y-2">
                    {s.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-slate-900 shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Deliverables box */}
                <div className="bg-neutral-100/80 rounded-xl p-3.5 text-xs text-slate-700 space-y-1">
                  <span className="font-semibold text-slate-900 text-[11px] block uppercase tracking-wider">
                    Livrables concrets :
                  </span>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-600 text-[11px]">
                    {s.deliverables.map((d, i) => (
                      <li key={i}>{d}</li>
                    ))}
                  </ul>
                </div>

              </div>

              {/* Bottom trigger CTA */}
              <div className="pt-6 mt-6 border-t border-neutral-200 flex items-center justify-between">
                <span className="text-xs text-slate-500 italic hidden sm:inline">
                  {s.forWho}
                </span>
                <button
                  onClick={() => onOpenBooking(`Accompagnement : ${s.title}`)}
                  className="px-4 py-2 text-xs font-semibold text-slate-900 bg-white border border-neutral-300 rounded-lg hover:bg-neutral-50 transition-all flex items-center gap-1.5 shadow-2xs ml-auto cursor-pointer"
                >
                  <span>Demander un devis</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
