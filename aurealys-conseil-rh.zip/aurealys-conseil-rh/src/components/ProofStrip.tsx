import React from 'react';
import { ShieldAlert, Clock, Scale, Building2 } from 'lucide-react';

export const ProofStrip: React.FC = () => {
  const metrics = [
    {
      value: "8+ ans",
      label: "D'expertise terrain",
      detail: "Multi-sites & multi-conventionnelles",
      icon: Scale,
    },
    {
      value: "0 litige",
      label: "Prud'homal imprévu",
      detail: "Sur l'ensemble des procédures sécurisées",
      icon: ShieldAlert,
    },
    {
      value: "24-48h",
      label: "Délai de réactivité",
      detail: "Prise en charge d'urgence pour les dirigeants",
      icon: Clock,
    },
    {
      value: "100%",
      label: "Sur-mesure TPE / PME",
      detail: "Du terrain jusqu'aux conventions collectives",
      icon: Building2,
    },
  ];

  return (
    <section className="bg-slate-900 text-white py-10 border-y border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-6 divide-y md:divide-y-0 md:divide-x divide-slate-800/80">
          {metrics.map((m, idx) => {
            const Icon = m.icon;
            return (
              <div 
                key={idx} 
                className={`flex flex-col items-start ${idx > 0 ? 'pt-6 md:pt-0 md:pl-6' : ''}`}
              >
                <div className="flex items-center gap-2 mb-1.5 text-amber-400">
                  <Icon className="w-4 h-4" />
                  <span className="text-2xl sm:text-3xl font-extrabold tracking-tight font-display tabular-nums">
                    {m.value}
                  </span>
                </div>
                <span className="text-sm font-semibold text-slate-100">
                  {m.label}
                </span>
                <span className="text-xs text-slate-400 mt-0.5">
                  {m.detail}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
