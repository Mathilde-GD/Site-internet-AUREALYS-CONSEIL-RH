import React, { useState } from 'react';
import { FAQS } from '../data/content';
import { ChevronDown, HelpCircle, Phone, Calendar } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface FAQSectionProps {
  onOpenBooking: () => void;
}

export const FAQSection: React.FC<FAQSectionProps> = ({ onOpenBooking }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section className="py-20 bg-[#F8F9FA] border-b border-neutral-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase mb-2">
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
            <span>Foire Aux Questions</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="text-slate-500 font-normal normal-case">Réponses Pratiques</span>
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Questions Fréquentes des Chefs d'Entreprise
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Toutes les réponses pour aborder notre collaboration en toute clarté.
          </p>
        </div>

        {/* Accordion list */}
        <div className="space-y-3">
          {FAQS.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="rounded-xl border border-neutral-200 bg-white overflow-hidden transition-all shadow-2xs"
              >
                <button
                  onClick={() => toggle(index)}
                  className="w-full py-4 px-6 text-left flex items-center justify-between gap-4 hover:bg-neutral-50/50 transition-colors cursor-pointer"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm sm:text-base font-bold text-slate-900 font-display">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-500 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-slate-900' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-6 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-neutral-100 bg-[#FCFCFA]">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Need more details prompt */}
        <div className="mt-10 p-6 rounded-xl bg-white border border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="text-xs text-slate-600">
            <span className="font-bold text-slate-900 block text-sm mb-0.5">
              Une autre question spécifique à votre secteur ou CCN ?
            </span>
            <span>Mathilde vous répond directement par téléphone ou email.</span>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <a
              href={`tel:${COMPANY_INFO.phoneRaw}`}
              className="px-4 py-2.5 rounded-lg border border-neutral-300 text-slate-800 text-xs font-semibold hover:bg-neutral-50 transition-colors"
            >
              {COMPANY_INFO.phoneDisplay}
            </a>
            <button
              onClick={onOpenBooking}
              className="px-4 py-2.5 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Prendre rendez-vous
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
