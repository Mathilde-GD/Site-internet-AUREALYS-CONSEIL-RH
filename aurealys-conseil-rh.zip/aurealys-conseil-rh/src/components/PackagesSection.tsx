import React from 'react';
import { PACKAGES } from '../data/content';
import { Check, Star, ArrowRight, Sparkles, Building2, HelpCircle, Shield, Award, Zap } from 'lucide-react';

interface PackagesSectionProps {
  onOpenBooking: (packageName?: string) => void;
}

export const PackagesSection: React.FC<PackagesSectionProps> = ({ onOpenBooking }) => {
  return (
    <section id="formules" className="py-20 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase mb-2">
            <span>Offres & Abonnements</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="text-slate-500 font-normal normal-case">Formules Claires & Modulables</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display">
            3 Packs d'Accompagnement Adaptés à Votre Entreprise
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Du filet de sécurité juridique indispensable jusqu'à la direction des ressources humaines externalisée en temps partagé, choisissez le niveau d'intervention qui correspond à votre rythme et vos ambitions.
          </p>
        </div>

        {/* 3 Packages Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {PACKAGES.map((pkg) => {
            const isPremium = pkg.id === 'pack-premium';
            const isPilotage = pkg.popular; // Pack Pilotage
            
            return (
              <div
                key={pkg.id}
                className={`rounded-2xl p-7 flex flex-col justify-between transition-all relative ${
                  isPilotage
                    ? 'bg-slate-900 text-white shadow-xl ring-2 ring-slate-900 lg:-translate-y-2'
                    : isPremium
                    ? 'bg-gradient-to-b from-[#FAF8F5] to-white text-slate-900 border-2 border-amber-300/80 shadow-md'
                    : 'bg-[#FCFCFA] text-slate-900 border border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <div>
                  {/* Badge */}
                  {isPilotage ? (
                    <div className="inline-flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider bg-amber-400 text-slate-950 px-2.5 py-1 rounded-sm mb-4 shadow-2xs">
                      <Star className="w-3 h-3 fill-slate-950" />
                      <span>Formule la plus plébiscitée</span>
                    </div>
                  ) : isPremium ? (
                    <div className="inline-flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider bg-slate-900 text-amber-300 px-2.5 py-1 rounded-sm mb-4">
                      <Award className="w-3 h-3 text-amber-300" />
                      <span>Excellence & Multi-Sites</span>
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider bg-neutral-200/70 text-slate-700 px-2.5 py-1 rounded-sm mb-4">
                      <Shield className="w-3 h-3 text-slate-600" />
                      <span>Fondations Juridiques</span>
                    </div>
                  )}

                  <h3 className={`text-2xl font-bold font-display ${isPilotage ? 'text-white' : 'text-slate-900'}`}>
                    {pkg.name}
                  </h3>
                  
                  <span className={`text-xs font-semibold block mt-1 ${isPilotage ? 'text-amber-300' : 'text-amber-900'}`}>
                    {pkg.type}
                  </span>

                  <p className={`text-xs mt-3 leading-relaxed ${isPilotage ? 'text-slate-300' : 'text-slate-600'}`}>
                    {pkg.tagline}
                  </p>

                  {/* Ideal for box */}
                  <div className={`mt-4 p-3 rounded-xl text-xs leading-snug ${isPilotage ? 'bg-slate-800 text-slate-200' : 'bg-neutral-100 text-slate-700'}`}>
                    <strong className="block text-[10px] uppercase tracking-wider mb-0.5 opacity-75">
                      Idéal pour :
                    </strong>
                    {pkg.idealFor}
                  </div>

                  {/* Features list */}
                  <div className="mt-6">
                    <span className={`text-[11px] font-bold uppercase tracking-wider block mb-3 ${isPilotage ? 'text-slate-400' : 'text-slate-500'}`}>
                      Inclus dans cette formule :
                    </span>
                    <ul className="space-y-3 text-xs">
                      {pkg.features.map((feat, i) => (
                        <li key={i} className="flex items-start gap-2.5">
                          <Check className={`w-4 h-4 shrink-0 mt-0.5 ${isPilotage ? 'text-amber-400' : 'text-slate-900'}`} />
                          <span className={isPilotage ? 'text-slate-200' : 'text-slate-700'}>
                            {feat}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Action CTA */}
                <div className="pt-8 mt-8 border-t border-neutral-200/20">
                  <button
                    onClick={() => onOpenBooking(`Intéressé par : ${pkg.name}`)}
                    className={`w-full py-3 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isPilotage
                        ? 'bg-amber-400 text-slate-950 hover:bg-amber-300 shadow-md font-bold'
                        : isPremium
                        ? 'bg-slate-900 text-white hover:bg-slate-800 shadow-sm'
                        : 'bg-white text-slate-900 border border-neutral-300 hover:bg-neutral-50 shadow-2xs'
                    }`}
                  >
                    <span>{pkg.ctaLabel}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

        {/* Reassurance strip */}
        <div className="mt-14 p-6 sm:p-8 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-base font-bold text-slate-900 font-display">
              Vous hésitez entre le Pack Essentiel, Pilotage ou Premium ?
            </h4>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
              Lors du diagnostic initial offert de 30 minutes, Mathilde analyse vos effectifs, vos conventions collectives et la complexité de votre organisation pour vous orienter vers la solution la plus juste.
            </p>
          </div>
          <button
            onClick={() => onOpenBooking("Conseil personnalisé sur le choix de pack")}
            className="w-full md:w-auto px-6 py-3 rounded-lg bg-slate-900 text-white text-xs sm:text-sm font-semibold hover:bg-slate-800 transition-colors shrink-0 shadow-sm cursor-pointer whitespace-nowrap"
          >
            Échanger gratuitement avec Mathilde &rarr;
          </button>
        </div>

      </div>
    </section>
  );
};
