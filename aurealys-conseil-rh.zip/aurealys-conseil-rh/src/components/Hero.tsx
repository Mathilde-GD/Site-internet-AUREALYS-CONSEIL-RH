import React from 'react';
import { Calendar, ShieldCheck, Scale, ArrowRight, Play, CheckCircle2, Building2 } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface HeroProps {
  onOpenBooking: (type?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section className="relative pt-8 pb-16 md:pt-14 md:pb-24 overflow-hidden border-b border-neutral-200/60">
      {/* Subtle architectural background grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:24px_24px] opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Proposition & CTA (7 cols) */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-6">
            
            {/* Editorial kicker with official emblem */}
            <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-700 tracking-wide uppercase">
              <div className="w-6 h-6 rounded-md overflow-hidden border border-amber-500/40 bg-[#0C1527] shadow-2xs shrink-0">
                <img
                  src="/src/assets/images/aurealys_logo_gold_1792406640670.jpg"
                  alt="Logo Auréalys"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover scale-160 -translate-y-0.5"
                />
              </div>
              <span>Conseil RH & Droit Social · TPE & PME</span>
              <span aria-hidden="true" className="text-slate-400">·</span>
              <span className="text-slate-500 font-normal normal-case">Spécialiste Multi-Sites & Multi-CCN</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 leading-[1.12] tracking-tight text-balance font-display">
              Sécurisez vos décisions RH et pilotez vos équipes l'esprit serein.
            </h1>

            {/* Value proposition paragraph */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              Mathilde Galland allie la <strong className="font-semibold text-slate-900">rigueur du droit social</strong> et le <strong className="font-semibold text-slate-900">pragmatisme du terrain RH</strong>. Forte de plus de 8 ans d'expérience acquise principalement en environnements <strong className="font-semibold text-slate-900">multi-sites et multi-conventionnels</strong>, elle apporte des réponses immédiates sans les contraintes d'un poste fixe.
            </p>

            {/* Core guarantees */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 w-full text-xs text-slate-700">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-900 shrink-0" />
                <span>Intervention sous 24h à 48h en cas d'urgence</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-900 shrink-0" />
                <span>Gestion experte multi-conventions & multi-sites</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-900 shrink-0" />
                <span>Présence sur site ou hotline dédiée dirigeant</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-900 shrink-0" />
                <span>Membre Réseau AURA PEP'S & Plaine de l'Ain</span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-2 w-full sm:w-auto">
              <button
                onClick={() => onOpenBooking("Diagnostic RH Offert (30 min)")}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2.5 group active:scale-[0.98] cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Réserver un diagnostic RH offert (30 min)</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <a
                href="#podcast"
                className="px-5 py-3.5 text-sm font-semibold text-slate-800 bg-white border border-neutral-300 rounded-lg hover:bg-neutral-50 transition-all flex items-center justify-center gap-2 shadow-xs"
              >
                <Play className="w-4 h-4 text-amber-700 fill-amber-700" />
                <span>Dernier épisode : « Le Bureau & la Loi »</span>
              </a>
            </div>

            {/* Regional trust marker */}
            <div className="pt-2 text-xs text-slate-500 flex flex-wrap items-center gap-x-2 gap-y-1">
              <span>{COMPANY_INFO.address}</span>
              <span aria-hidden="true">·</span>
              <span>Ain (01), Rhône (69) & toute la France à distance</span>
            </div>
          </div>

          {/* Right Column: Visual Anchor (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-neutral-200/90 shadow-xl bg-white">
              
              {/* Main visual */}
              <div className="aspect-[4/3] sm:aspect-[16/11] relative overflow-hidden bg-neutral-100">
                <img
                  src="/src/assets/images/hero_hr_advisory_1792404189556.jpg"
                  alt="Cabinet de conseil en ressources humaines Auréalys Conseil RH"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center"
                  loading="eager"
                />
                
                {/* Subtle scrim at bottom for badge contrast */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />

                {/* Overlay Badge */}
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="flex items-center gap-2 text-xs font-semibold tracking-wide text-amber-300 uppercase mb-1">
                    <Scale className="w-3.5 h-3.5" />
                    <span>Droit Social & Opérationnel RH</span>
                  </div>
                  <p className="text-sm font-medium text-white/95 line-clamp-2">
                    Accompagnement personnalisé pour dirigeants et managers de proximité.
                  </p>
                </div>
              </div>

              {/* Sub-strip underneath photo */}
              <div className="p-4 bg-slate-50 border-t border-neutral-200 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 text-slate-700">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="font-medium">Créneaux diagnostic disponibles cette semaine</span>
                </div>
                <button
                  onClick={() => onOpenBooking("Diagnostic RH Offert (30 min)")}
                  className="text-slate-900 font-semibold hover:underline shrink-0 cursor-pointer"
                >
                  Choisir une date &rarr;
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
