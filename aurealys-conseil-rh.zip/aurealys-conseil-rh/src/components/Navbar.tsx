import React, { useState } from 'react';
import { Menu, X, Phone, Calendar, Headphones } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface NavbarProps {
  onOpenBooking: (type?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#FCFCFA]/95 backdrop-blur-md border-b border-neutral-200/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Official Logo & Brand Lockup */}
          <a 
            href="#" 
            className="flex items-center whitespace-nowrap shrink-0 group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg overflow-hidden border border-amber-500/40 bg-[#0C1527] shadow-sm shrink-0 relative">
                <img
                  src="/src/assets/images/aurealys_logo_gold_1792406640670.jpg"
                  alt="Logo Auréalys Conseil RH"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover scale-155 -translate-y-1"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-extrabold tracking-[0.06em] text-slate-900 font-display leading-tight uppercase">
                  Auréalys
                </span>
                <span className="text-[10px] text-amber-900 font-bold tracking-[0.2em] uppercase leading-tight">
                  Conseil RH
                </span>
              </div>
            </div>
          </a>

          {/* Zone 2: 4–5 clean single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-7 text-[13.5px] font-medium text-slate-600">
            <a 
              href="#expertise" 
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Double Expertise
            </a>
            <a 
              href="#parcours" 
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Parcours Client
            </a>
            <a 
              href="#formules" 
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Les 3 Packs
            </a>
            <a 
              href="#podcast" 
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 text-amber-800 font-semibold"
            >
              <Headphones className="w-3.5 h-3.5" />
              Podcast & YouTube
            </a>
            <a 
              href="#audit-express" 
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Audit Express
            </a>
            <a 
              href="#a-propos" 
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              À Propos
            </a>
          </nav>

          {/* Zone 3: 1 primary action + subtle direct phone */}
          <div className="hidden sm:flex items-center gap-4 shrink-0">
            <a
              href={`tel:${COMPANY_INFO.phoneRaw}`}
              className="text-xs font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
              title="Joindre directement Mathilde Galland"
            >
              <Phone className="w-3.5 h-3.5 text-slate-500" />
              <span>{COMPANY_INFO.phoneDisplay}</span>
            </a>

            <button
              onClick={() => onOpenBooking("Diagnostic RH Offert (30 min)")}
              className="px-4 py-2.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-all shadow-sm flex items-center gap-2 whitespace-nowrap shrink-0 active:scale-[0.98] cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Prendre Rendez-vous</span>
            </button>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => onOpenBooking("Diagnostic RH Offert (30 min)")}
              className="px-3 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-all flex items-center gap-1.5"
            >
              <Calendar className="w-3 h-3" />
              <span>RdV Offert</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-slate-900 rounded-md focus:outline-none"
              aria-label="Ouvrir le menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-neutral-200 bg-[#FCFCFA] px-4 pt-3 pb-6 space-y-3">
          <nav className="flex flex-col space-y-2 text-sm font-medium text-slate-700">
            <a 
              href="#expertise" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-lg hover:bg-neutral-100 transition-colors"
            >
              Double Expertise (Droit & RH)
            </a>
            <a 
              href="#parcours" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-lg hover:bg-neutral-100 transition-colors"
            >
              Parcours Client en 4 Étapes
            </a>
            <a 
              href="#services" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-lg hover:bg-neutral-100 transition-colors"
            >
              Nos Accompagnements & Offres
            </a>
            <a 
              href="#podcast" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-lg hover:bg-amber-50 text-amber-900 font-semibold transition-colors flex items-center gap-2"
            >
              <Headphones className="w-4 h-4 text-amber-700" />
              Podcast « Le Bureau et la Loi » & YouTube
            </a>
            <a 
              href="#audit-express" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-lg hover:bg-neutral-100 transition-colors"
            >
              Diagnostic Risques RH Express (2 min)
            </a>
            <a 
              href="#a-propos" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-lg hover:bg-neutral-100 transition-colors"
            >
              À Propos de Mathilde Galland
            </a>
            <a 
              href="#contact" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-lg hover:bg-neutral-100 transition-colors"
            >
              Contact & Accès
            </a>
          </nav>

          <div className="pt-3 border-t border-neutral-200 flex flex-col gap-2.5">
            <a
              href={`tel:${COMPANY_INFO.phoneRaw}`}
              className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-neutral-100 text-slate-800 text-xs font-semibold hover:bg-neutral-200 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-slate-600" />
              <span>Appeler Mathilde : {COMPANY_INFO.phoneDisplay}</span>
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking("Diagnostic RH Offert (30 min)");
              }}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>Réserver mon diagnostic offert (30 min)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
