import React from 'react';
import { Scale, Users, ShieldCheck, HeartHandshake, CheckCircle2, ArrowRight } from 'lucide-react';
import { DUAL_EXPERTISE_POINTS } from '../data/content';

interface DualExpertiseProps {
  onOpenBooking: (type?: string) => void;
}

export const DualExpertise: React.FC<DualExpertiseProps> = ({ onOpenBooking }) => {
  return (
    <section id="expertise" className="py-20 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase mb-2">
            <span>Positionnement Unique</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="text-slate-500 font-normal normal-case">La Valeur Ajoutée Auréalys</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display">
            La double expertise qui change tout pour un dirigeant de PME
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Pourquoi choisir entre la sécurité juridique d'un juriste et l'agilité humaine d'un responsable RH de terrain ? Auréalys fusionne les deux pour vous offrir un accompagnement 360°, sans compromis.
          </p>
        </div>

        {/* 2-Column Split of the Dual Superpower */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          
          {/* Pillar 1: Droit Social */}
          <div className="rounded-2xl border border-neutral-200 bg-[#FCFCFA] p-8 flex flex-col justify-between shadow-xs hover:border-neutral-300 transition-all">
            <div className="space-y-6">
              
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-slate-900 text-amber-300 flex items-center justify-center shadow-xs">
                  <Scale className="w-6 h-6" />
                </div>
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-500 bg-neutral-200/60 px-2.5 py-1 rounded">
                  Pilier 01 · Juridique
                </span>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-slate-900 font-display">
                  {DUAL_EXPERTISE_POINTS[0].title}
                </h3>
                <span className="text-sm font-semibold text-amber-800 block mt-1">
                  {DUAL_EXPERTISE_POINTS[0].subtitle}
                </span>
                <p className="text-sm text-slate-600 mt-3 leading-relaxed">
                  {DUAL_EXPERTISE_POINTS[0].description}
                </p>
              </div>

              {/* Photo representation */}
              <div className="aspect-[16/9] rounded-xl overflow-hidden border border-neutral-200/90 relative bg-neutral-100">
                <img
                  src="/src/assets/images/hr_audit_compliance_1792404190356.jpg"
                  alt="Audit juridique et relecture de contrats de travail"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>

              {/* Bullet points */}
              <ul className="space-y-2.5 pt-2">
                {DUAL_EXPERTISE_POINTS[0].points.map((pt, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                    <ShieldCheck className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                    <span>{pt}</span>
                  </li>
                ))}
              </ul>

            </div>

            <div className="pt-6 mt-6 border-t border-neutral-200 flex items-center justify-between text-xs text-slate-500">
              <span>Objectif : Zéro risque contentieux</span>
              <span className="font-semibold text-slate-900">Code du Travail & CCN</span>
            </div>
          </div>

          {/* Pillar 2: Opérationnel RH */}
          <div className="rounded-2xl border border-neutral-200 bg-[#FCFCFA] p-8 flex flex-col justify-between shadow-xs hover:border-neutral-300 transition-all">
            <div className="space-y-6">
              
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-slate-900 text-amber-300 flex items-center justify-center shadow-xs">
                  <Users className="w-6 h-6" />
                </div>
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-500 bg-neutral-200/60 px-2.5 py-1 rounded">
                  Pilier 02 · Opérationnel
                </span>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-slate-900 font-display">
                  {DUAL_EXPERTISE_POINTS[1].title}
                </h3>
                <span className="text-sm font-semibold text-amber-800 block mt-1">
                  {DUAL_EXPERTISE_POINTS[1].subtitle}
                </span>
                <p className="text-sm text-slate-600 mt-3 leading-relaxed">
                  {DUAL_EXPERTISE_POINTS[1].description}
                </p>
              </div>

              {/* Photo representation */}
              <div className="aspect-[16/9] rounded-xl overflow-hidden border border-neutral-200/90 relative bg-neutral-100">
                <img
                  src="/src/assets/images/team_onboarding_meeting_1792404191155.jpg"
                  alt="Management humain et entretiens de recrutement"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>

              {/* Bullet points */}
              <ul className="space-y-2.5 pt-2">
                {DUAL_EXPERTISE_POINTS[1].points.map((pt, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                    <HeartHandshake className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                    <span>{pt}</span>
                  </li>
                ))}
              </ul>

            </div>

            <div className="pt-6 mt-6 border-t border-neutral-200 flex items-center justify-between text-xs text-slate-500">
              <span>Objectif : Sérénité & Cohésion d'équipe</span>
              <span className="font-semibold text-slate-900">Présentiel & Distanciel</span>
            </div>
          </div>

        </div>

        {/* Comparison Callout: What traditional approaches miss */}
        <div className="mt-12 bg-slate-50 rounded-2xl border border-neutral-200 p-6 sm:p-8">
          <h4 className="text-base font-bold text-slate-900 font-display mb-4">
            Comparatif : Pourquoi un dirigeant choisit Auréalys Conseil RH
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-600 divide-y md:divide-y-0 md:divide-x divide-neutral-200">
            <div className="space-y-1.5 md:pr-4">
              <span className="font-semibold text-slate-900 block text-sm">Avocat en droit social</span>
              <p>Très pointu en cas de procès mais facturation horaire élevée, peu disponible pour le quotidien managérial et absent du terrain opérationnel.</p>
            </div>
            <div className="space-y-1.5 pt-4 md:pt-0 md:px-4">
              <span className="font-semibold text-slate-900 block text-sm">Expert-comptable / Paie</span>
              <p>Excellent pour établir les bulletins et les déclarations, mais n'a ni le temps ni la responsabilité de rédiger vos accords ou de gérer vos conflits d'équipe.</p>
            </div>
            <div className="space-y-1.5 pt-4 md:pt-0 md:pl-4 bg-amber-50/60 p-3 rounded-lg border border-amber-200/50">
              <span className="font-bold text-slate-900 block text-sm flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                Auréalys Conseil RH
              </span>
              <p className="text-slate-700 font-medium">Le pont idéal : une juriste disponible qui parle le langage des patrons, rédige vos actes et vient au contact de vos équipes sur site.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
