import React from 'react';
import { TESTIMONIALS } from '../data/content';
import { Quote, Star, MapPin, Building, ShieldCheck } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section className="py-20 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase mb-2">
            <span>Retours d'Expérience</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="text-slate-500 font-normal normal-case">Témoignages de Dirigeants</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display">
            Ce que nos clients chefs d'entreprise disent d'Auréalys
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            De la Plaine de l'Ain à la région lyonnaise, découvrez comment nos interventions sécurisent les décisions managériales au quotidien.
          </p>
        </div>

        {/* Testimonials 3-Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="rounded-2xl border border-neutral-200 bg-[#FCFCFA] p-6 sm:p-7 flex flex-col justify-between shadow-2xs hover:border-neutral-300 transition-all"
            >
              <div className="space-y-4">
                
                {/* Metric badge */}
                <div className="bg-amber-50 border border-amber-200/80 rounded-lg px-3 py-1.5 text-xs font-bold text-amber-950 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
                  <span>Impact : {t.metric}</span>
                </div>

                {/* Quote */}
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed italic">
                  « {t.quote} »
                </p>

              </div>

              {/* Author metadata */}
              <div className="pt-5 mt-5 border-t border-neutral-200 space-y-1">
                <span className="text-sm font-bold text-slate-900 block font-display">
                  {t.name}
                </span>
                <span className="text-xs text-slate-600 block font-medium">
                  {t.role} · {t.company}
                </span>
                <div className="flex items-center gap-1 text-[11px] text-slate-400 pt-0.5">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  <span>{t.location}</span>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
