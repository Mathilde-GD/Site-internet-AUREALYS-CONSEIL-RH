import React, { useState } from 'react';
import { PODCAST_EPISODES, COMPANY_INFO, PodcastEpisode } from '../data/content';
import { Headphones, Play, Youtube, Clock, ExternalLink, Sparkles, BookOpen, Volume2, Pause, Flame } from 'lucide-react';

interface PodcastSectionProps {
  onOpenBooking: (topic?: string) => void;
}

export const PodcastSection: React.FC<PodcastSectionProps> = ({ onOpenBooking }) => {
  // Latest episode is the first one in the list
  const [activeEpisode, setActiveEpisode] = useState<PodcastEpisode>(PODCAST_EPISODES[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const togglePlay = (ep: PodcastEpisode) => {
    if (activeEpisode.id === ep.id) {
      setIsPlaying(!isPlaying);
    } else {
      setActiveEpisode(ep);
      setIsPlaying(true);
    }
  };

  return (
    <section id="podcast" className="py-20 bg-[#FAF9F5] border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-900 tracking-wide uppercase mb-2">
              <Headphones className="w-3.5 h-3.5 text-amber-700" />
              <span>Médias & Décryptages Pratiques</span>
              <span aria-hidden="true" className="text-amber-400">·</span>
              <span className="text-amber-800 font-normal normal-case">Par Mathilde Galland</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display">
              Le Bureau et la Loi · Le Podcast & Chaîne YouTube
            </h2>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">
              Le droit du travail décodé pour les dirigeants de TPE et PME. Découvrez notre dernier épisode sur les risques de contentieux liés aux performances non formalisées et nos conseils concrets pour sécuriser vos pratiques.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <a
              href={COMPANY_INFO.youtubeChannelUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-3 text-xs sm:text-sm font-semibold text-white bg-[#FF0000] hover:bg-[#CC0000] rounded-lg transition-all flex items-center gap-2 shadow-xs"
            >
              <Youtube className="w-4 h-4 fill-white" />
              <span>S'abonner sur YouTube</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-80" />
            </a>
          </div>
        </div>

        {/* Featured Player & Episode Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left: Interactive Episode Focus / Player (5 cols) */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-neutral-200 p-6 sm:p-8 shadow-sm relative overflow-hidden">
            
            {activeEpisode.isLatest && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider mb-4 shadow-2xs">
                <Flame className="w-3 h-3 fill-slate-950" />
                <span>Dernier Épisode</span>
              </div>
            )}

            <div className="flex items-center justify-between text-xs text-slate-500 mb-3 pb-3 border-b border-neutral-100">
              <div className="flex items-center gap-2 text-amber-800 font-semibold">
                <Volume2 className="w-4 h-4" />
                <span>Extrait de l'épisode</span>
              </div>
              <span className="font-mono text-slate-400">{activeEpisode.duration}</span>
            </div>

            <div className="space-y-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 block">
                {activeEpisode.category}
              </span>
              <h3 className="text-xl font-bold text-slate-900 font-display leading-snug">
                {activeEpisode.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {activeEpisode.description}
              </p>

              {/* Legal Takeaway highlight */}
              <div className="bg-amber-50/80 border border-amber-200/60 rounded-xl p-4 text-xs">
                <span className="font-bold text-amber-950 block mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                  À retenir pour votre entreprise :
                </span>
                <p className="text-amber-900 font-medium italic">
                  « {activeEpisode.takeaway} »
                </p>
              </div>

              {/* Simulated Audio Bar Controls */}
              <div className="pt-2">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => togglePlay(activeEpisode)}
                    className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center hover:bg-slate-800 transition-all shrink-0 shadow-md cursor-pointer"
                    aria-label={isPlaying ? "Mettre en pause" : "Écouter l'extrait"}
                  >
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                  </button>
                  <div className="flex-1">
                    <div className="h-1.5 w-full bg-neutral-200 rounded-full overflow-hidden">
                      <div className={`h-full bg-slate-900 rounded-full transition-all duration-300 ${isPlaying ? 'w-2/3 animate-pulse' : 'w-1/4'}`} />
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                      <span>{isPlaying ? '04:15' : '00:00'}</span>
                      <span>{activeEpisode.duration}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-4 border-t border-neutral-100 flex flex-col sm:flex-row gap-2.5">
                <a
                  href={activeEpisode.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2.5 px-3 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-slate-800 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <Youtube className="w-3.5 h-3.5 text-[#FF0000]" />
                  <span>Regarder sur YouTube</span>
                </a>
                <button
                  onClick={() => onOpenBooking(`Conseil suite à l'épisode : ${activeEpisode.title}`)}
                  className="py-2.5 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  En parler avec Mathilde
                </button>
              </div>
            </div>
          </div>

          {/* Right: List of Episodes (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
              Derniers épisodes disponibles
            </span>

            {PODCAST_EPISODES.map((ep) => {
              const isSelected = activeEpisode.id === ep.id;
              return (
                <div
                  key={ep.id}
                  onClick={() => setActiveEpisode(ep)}
                  className={`p-5 rounded-xl border transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                    isSelected
                      ? 'bg-white border-slate-900 shadow-sm ring-1 ring-slate-900'
                      : 'bg-white/70 border-neutral-200 hover:bg-white hover:border-neutral-300'
                  }`}
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2 text-[11px] text-slate-500">
                      {ep.isLatest && (
                        <span className="bg-amber-400 text-slate-950 font-bold px-2 py-0.5 rounded text-[10px] uppercase">
                          Dernier
                        </span>
                      )}
                      <span className="font-semibold text-amber-800">{ep.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1 font-mono">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {ep.duration}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-slate-900 font-display">
                      {ep.title}
                    </h4>
                    <p className="text-xs text-slate-600 line-clamp-1">
                      {ep.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        togglePlay(ep);
                      }}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-neutral-100 hover:bg-neutral-200 text-slate-800 flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {isSelected && isPlaying ? (
                        <>
                          <Pause className="w-3 h-3" />
                          <span>Pause</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3 h-3" />
                          <span>Écouter</span>
                        </>
                      )}
                    </button>
                    <a
                      href={ep.youtubeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="p-2 rounded-lg text-slate-500 hover:text-[#FF0000] hover:bg-neutral-100 transition-colors"
                      title="Ouvrir sur YouTube"
                    >
                      <Youtube className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              );
            })}

            {/* Banner for YouTube subscribe */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-slate-900 to-slate-800 text-white flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-600 flex items-center justify-center shrink-0">
                  <Youtube className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h5 className="text-xs sm:text-sm font-bold font-display">
                    Retrouvez Mathilde en vidéo sur YouTube
                  </h5>
                  <p className="text-[11px] text-slate-300">
                    Conseils réguliers, décryptages jurisprudence et astuces RH de terrain.
                  </p>
                </div>
              </div>
              <a
                href={COMPANY_INFO.youtubeChannelUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-4 py-2 rounded-lg bg-white text-slate-900 text-xs font-bold hover:bg-neutral-100 transition-colors shrink-0 text-center"
              >
                Accéder à la chaîne
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
