import React, { useState } from 'react';
import { CUSTOMER_JOURNEY } from '../data/content';
import { Calendar, CheckCircle2, ArrowRight, Clock, FileCheck } from 'lucide-react';

interface CustomerJourneyProps {
  onOpenBooking: (type?: string) => void;
}

export const CustomerJourney: React.FC<CustomerJourneyProps> = ({ onOpenBooking }) => {
  const [activeStep, setActiveStep] = useState<number>(0);

  return (
    <section id="parcours" className="py-20 bg-[#F8F9FA] border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase mb-2">
            <span>Méthode & Transparence</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="text-slate-500 font-normal normal-case">Parcours Prospect & Client</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display">
            Comment se déroule notre collaboration ?
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Un processus clair en 4 étapes pour vous décharger de la charge mentale RH en toute confiance, dès le premier contact.
          </p>
        </div>

        {/* Desktop 4-Step Flow */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
          {CUSTOMER_JOURNEY.map((item, index) => {
            const isSelected = activeStep === index;
            return (
              <div
                key={item.step}
                onClick={() => setActiveStep(index)}
                className={`relative flex flex-col p-6 rounded-xl border transition-all cursor-pointer ${
                  isSelected 
                    ? 'bg-white border-slate-900 shadow-md ring-1 ring-slate-900' 
                    : 'bg-white/80 border-neutral-200 hover:border-neutral-300 hover:bg-white shadow-xs'
                }`}
              >
                {/* Step indicator */}
                <div className="flex items-center justify-between mb-4">
                  <span className={`text-xs font-bold font-mono px-2 py-1 rounded ${isSelected ? 'bg-slate-900 text-white' : 'bg-neutral-100 text-slate-600'}`}>
                    Étape {item.step}
                  </span>
                  <div className="flex items-center gap-1 text-[11px] text-slate-500">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>{item.duration}</span>
                  </div>
                </div>

                <h3 className="text-lg font-bold text-slate-900 font-display mb-1">
                  {item.title}
                </h3>
                <span className="text-xs font-medium text-amber-800 mb-3 block">
                  {item.subtitle}
                </span>

                <p className="text-xs text-slate-600 leading-relaxed flex-1">
                  {item.description}
                </p>

                <div className="mt-4 pt-3 border-t border-neutral-100 flex items-start gap-2 text-xs text-slate-700 bg-neutral-50/70 p-2.5 rounded-lg">
                  <FileCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-slate-900 text-[11px] block uppercase tracking-wider">Livrable :</span>
                    <span className="text-[11px] leading-snug text-slate-600">{item.deliverable}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner with Direct Call to Action */}
        <div className="mt-12 bg-white rounded-xl border border-neutral-200 p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-lg font-bold text-slate-900 font-display">
              Prêt à sécuriser votre entreprise dès cette semaine ?
            </h4>
            <p className="text-xs sm:text-sm text-slate-600">
              L'étape 1 est offerte : 30 minutes sans engagement avec Mathilde pour faire le point sur vos priorités RH.
            </p>
          </div>
          <button
            onClick={() => onOpenBooking("Diagnostic RH Offert (30 min)")}
            className="w-full md:w-auto px-6 py-3 text-xs sm:text-sm font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-2 shrink-0 shadow-sm cursor-pointer"
          >
            <Calendar className="w-4 h-4" />
            <span>Réserver mon échange gratuit de 30 min</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};
