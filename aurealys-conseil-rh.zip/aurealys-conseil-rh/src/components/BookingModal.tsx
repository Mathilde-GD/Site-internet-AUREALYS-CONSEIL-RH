import React, { useState } from 'react';
import { X, Calendar, Clock, CheckCircle2, Video, Phone, Building2, User, Mail, MessageSquare, Download, ExternalLink } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTopic?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, initialTopic }) => {
  if (!isOpen) return null;

  // Generate next 10 business days
  const getNextBusinessDays = () => {
    const days: { dateStr: string; label: string; rawDate: Date }[] = [];
    const now = new Date();
    let current = new Date(now);
    current.setDate(current.getDate() + 1); // Start tomorrow

    while (days.length < 8) {
      const dayOfWeek = current.getDay();
      // Skip Saturday (6) and Sunday (0)
      if (dayOfWeek !== 0 && dayOfWeek !== 6) {
        const dateStr = current.toISOString().split('T')[0];
        const label = current.toLocaleDateString('fr-FR', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
        });
        days.push({ dateStr, label, rawDate: new Date(current) });
      }
      current.setDate(current.getDate() + 1);
    }
    return days;
  };

  const businessDays = getNextBusinessDays();

  const timeSlots = ["09:00", "10:30", "11:45", "14:00", "15:30", "17:00"];

  const [consultationType, setConsultationType] = useState<string>("Diagnostic RH Offert (30 min)");
  const [meetingMode, setMeetingMode] = useState<string>("Visioconférence (Google Meet)");
  const [selectedDate, setSelectedDate] = useState<string>(businessDays[0]?.dateStr || "");
  const [selectedTime, setSelectedTime] = useState<string>("10:30");

  const [formData, setFormData] = useState({
    name: "",
    company: "",
    teamSize: "10-25 salariés",
    phone: "",
    email: "",
    notes: initialTopic || "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [bookingRef, setBookingRef] = useState<string>("");

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = "Votre nom est requis";
    if (!formData.company.trim()) newErrors.company = "Le nom de l'entreprise est requis";
    if (!formData.email.trim() || !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Une adresse email valide est requise";
    }
    if (!formData.phone.trim() || formData.phone.length < 8) {
      newErrors.phone = "Un numéro de téléphone valide est requis";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const ref = `AUR-${Math.floor(100000 + Math.random() * 900000)}`;
    setBookingRef(ref);
    setIsSubmitted(true);
  };

  // Helper to generate and download an .ics calendar file
  const downloadIcs = () => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    const [hours, minutes] = selectedTime.split(':').map(Number);
    
    const startDate = new Date(Date.UTC(year, month - 1, day, hours - 1, minutes)); // Approximate UTC
    const endDate = new Date(Date.UTC(year, month - 1, day, hours - 1, minutes + 30));

    const formatDate = (d: Date) => d.toISOString().replace(/-|:|\.\d+/g, '');

    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Aurealys Conseil RH//FR
CALSCALE:GREGORIAN
METHOD:REQUEST
BEGIN:VEVENT
SUMMARY:${consultationType} avec Mathilde Galland (Auréalys Conseil RH)
DESCRIPTION:Rendez-vous réservé par ${formData.name} (${formData.company}).\\nObjet: ${formData.notes || 'Diagnostic RH'}\\nContact: contact@aurealysconseilrh.fr - 07 63 43 43 78
LOCATION:${meetingMode}
DTSTART:${formatDate(startDate)}
DTEND:${formatDate(endDate)}
STATUS:CONFIRMED
ORGANIZER;CN=Mathilde Galland:mailto:contact@aurealysconseilrh.fr
ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=ACCEPTED;CN=${formData.name}:mailto:${formData.email}
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `RendezVous-Aurealys-${selectedDate}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getGoogleCalendarUrl = () => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    const [hours, minutes] = selectedTime.split(':').map(Number);
    const startStr = `${year}${String(month).padStart(2, '0')}${String(day).padStart(2, '0')}T${String(hours).padStart(2, '0')}${String(minutes).padStart(2, '0')}00`;
    const endMinutes = minutes + 30;
    const endStr = `${year}${String(month).padStart(2, '0')}${String(day).padStart(2, '0')}T${String(hours).padStart(2, '0')}${String(endMinutes).padStart(2, '0')}00`;
    
    const text = encodeURIComponent(`${consultationType} - Mathilde Galland (Auréalys)`);
    const details = encodeURIComponent(`Rendez-vous pour ${formData.company}. Contact Mathilde Galland: 07 63 43 43 78 - contact@aurealysconseilrh.fr`);
    const location = encodeURIComponent(meetingMode);

    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${text}&dates=${startStr}/${endStr}&details=${details}&location=${location}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="relative bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-8"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 block mb-0.5">
              Prise de Rendez-vous en Ligne
            </span>
            <h3 className="text-xl sm:text-2xl font-bold font-display">
              Échange Direct avec Mathilde Galland
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Fermer la fenêtre"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 max-h-[80vh] overflow-y-auto">
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Type selection */}
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-2">
                  1. Format de l'échange
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    "Diagnostic Offert (30 min)",
                    "Le Pack Essentiel",
                    "Le Pack Pilotage",
                    "Le Pack Premium"
                  ].map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setConsultationType(type)}
                      className={`py-2 px-2.5 rounded-lg text-xs font-semibold text-center border transition-all cursor-pointer ${
                        consultationType === type || (initialTopic && initialTopic.includes(type))
                          ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                          : 'border-neutral-200 hover:border-neutral-300 bg-white text-slate-700'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mode: Visio / Phone */}
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-2">
                  2. Modalité souhaitée
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {[
                    { label: "Visioconférence (Google Meet)", icon: Video },
                    { label: "Appel Téléphonique", icon: Phone }
                  ].map((m) => {
                    const Icon = m.icon;
                    return (
                      <button
                        key={m.label}
                        type="button"
                        onClick={() => setMeetingMode(m.label)}
                        className={`py-2 px-3 rounded-lg text-xs font-medium border flex items-center gap-2 cursor-pointer transition-all ${
                          meetingMode === m.label
                            ? 'border-slate-900 bg-slate-50 text-slate-900 font-semibold'
                            : 'border-neutral-200 text-slate-600'
                        }`}
                      >
                        <Icon className="w-4 h-4 text-slate-700" />
                        <span>{m.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Date & Time Slot Picker */}
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-2">
                  3. Choisissez votre date & horaire
                </label>
                
                {/* Horizontal date pill selector */}
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5 mb-3">
                  {businessDays.map((d) => (
                    <button
                      key={d.dateStr}
                      type="button"
                      onClick={() => setSelectedDate(d.dateStr)}
                      className={`py-2 px-1 rounded-md text-center text-xs transition-all cursor-pointer flex flex-col items-center justify-center ${
                        selectedDate === d.dateStr
                          ? 'bg-slate-900 text-white font-bold shadow-xs'
                          : 'bg-neutral-100 hover:bg-neutral-200 text-slate-700 font-medium'
                      }`}
                    >
                      <span className="capitalize text-[10px] opacity-80">{d.label.split(' ')[0]}</span>
                      <span className="font-bold text-xs">{d.label.split(' ')[1]}</span>
                    </button>
                  ))}
                </div>

                {/* Time slots */}
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {timeSlots.map((time) => (
                    <button
                      key={time}
                      type="button"
                      onClick={() => setSelectedTime(time)}
                      className={`py-2 px-2 text-center text-xs font-mono rounded-md border transition-all cursor-pointer ${
                        selectedTime === time
                          ? 'bg-amber-400 border-amber-500 text-slate-950 font-bold'
                          : 'border-neutral-200 hover:border-neutral-300 text-slate-700'
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>

              {/* Prospect Details */}
              <div className="space-y-3 pt-2 border-t border-neutral-100">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
                  4. Vos coordonnées professionnelles
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <input
                      type="text"
                      placeholder="Votre nom et prénom *"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full text-xs p-2.5 rounded-lg border bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900 ${
                        errors.name ? 'border-red-500' : 'border-neutral-200'
                      }`}
                    />
                    {errors.name && <span className="text-[10px] text-red-600 mt-0.5 block">{errors.name}</span>}
                  </div>

                  <div>
                    <input
                      type="text"
                      placeholder="Nom de votre entreprise *"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className={`w-full text-xs p-2.5 rounded-lg border bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900 ${
                        errors.company ? 'border-red-500' : 'border-neutral-200'
                      }`}
                    />
                    {errors.company && <span className="text-[10px] text-red-600 mt-0.5 block">{errors.company}</span>}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-1">
                    <select
                      value={formData.teamSize}
                      onChange={(e) => setFormData({ ...formData, teamSize: e.target.value })}
                      className="w-full text-xs p-2.5 rounded-lg border border-neutral-200 bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900"
                    >
                      <option value="1 à 9 salariés">&lt; 10 salariés</option>
                      <option value="10 à 25 salariés">10 à 25 salariés</option>
                      <option value="26 à 49 salariés">26 à 49 salariés</option>
                      <option value="50 salariés et +">50 salariés et +</option>
                    </select>
                  </div>

                  <div className="sm:col-span-1">
                    <input
                      type="tel"
                      placeholder="Téléphone direct *"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className={`w-full text-xs p-2.5 rounded-lg border bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900 ${
                        errors.phone ? 'border-red-500' : 'border-neutral-200'
                      }`}
                    />
                    {errors.phone && <span className="text-[10px] text-red-600 mt-0.5 block">{errors.phone}</span>}
                  </div>

                  <div className="sm:col-span-1">
                    <input
                      type="email"
                      placeholder="Email professionnel *"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className={`w-full text-xs p-2.5 rounded-lg border bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900 ${
                        errors.email ? 'border-red-500' : 'border-neutral-200'
                      }`}
                    />
                    {errors.email && <span className="text-[10px] text-red-600 mt-0.5 block">{errors.email}</span>}
                  </div>
                </div>

                <div>
                  <textarea
                    rows={2}
                    placeholder="Précisez brièvement votre enjeu (optionnel) : rupture, contrat, CSE, audit, recrutement..."
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-lg border border-neutral-200 bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 px-6 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Confirmer mon rendez-vous avec Mathilde Galland</span>
                </button>
                <p className="text-[11px] text-slate-500 text-center mt-2">
                  Confirmation immédiate · Vos données restent 100% confidentielles
                </p>
              </div>

            </form>
          ) : (
            /* Success confirmation state */
            <div className="py-6 text-center space-y-5">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                  Rendez-vous validé · Réf : {bookingRef}
                </span>
                <h4 className="text-2xl font-bold text-slate-900 font-display">
                  Merci {formData.name}, votre échange est planifié !
                </h4>
                <p className="text-sm text-slate-600 max-w-md mx-auto">
                  Mathilde Galland vous contactera le <strong>{selectedDate} à {selectedTime}</strong> via {meetingMode}.
                </p>
              </div>

              {/* Summary card */}
              <div className="bg-neutral-50 rounded-xl p-4 max-w-md mx-auto border border-neutral-200 text-left text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Entreprise :</span>
                  <span className="font-semibold text-slate-900">{formData.company} ({formData.teamSize})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Format :</span>
                  <span className="font-semibold text-slate-900">{consultationType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Date & Heure :</span>
                  <span className="font-semibold text-slate-900">{selectedDate} à {selectedTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Email de confirmation :</span>
                  <span className="font-semibold text-slate-900">{formData.email}</span>
                </div>
              </div>

              {/* Calendar add actions */}
              <div className="flex flex-col sm:flex-row gap-2.5 justify-center max-w-md mx-auto pt-2">
                <button
                  type="button"
                  onClick={downloadIcs}
                  className="py-2.5 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Ajouter à mon agenda (.ics)</span>
                </button>
                <a
                  href={getGoogleCalendarUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2.5 px-4 rounded-lg border border-neutral-300 hover:bg-neutral-100 text-slate-800 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Google Calendar</span>
                </a>
              </div>

              <div className="pt-4 border-t border-neutral-100 flex items-center justify-between text-xs text-slate-500 max-w-md mx-auto">
                <span>En cas d'urgence préalable :</span>
                <a href={`tel:${COMPANY_INFO.phoneRaw}`} className="font-bold text-slate-900 hover:underline">
                  {COMPANY_INFO.phoneDisplay}
                </a>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="mt-2 text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
              >
                Fermer
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
