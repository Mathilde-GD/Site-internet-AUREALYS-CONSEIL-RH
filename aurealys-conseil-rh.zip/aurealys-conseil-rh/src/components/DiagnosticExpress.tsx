import React, { useState } from 'react';
import { AUDIT_QUESTIONS, AuditQuestion } from '../data/content';
import { ShieldAlert, ShieldCheck, CheckCircle2, AlertTriangle, ArrowRight, RotateCcw, Calendar, FileText } from 'lucide-react';

interface DiagnosticExpressProps {
  onOpenBooking: (scoreDetails?: string) => void;
}

export const DiagnosticExpress: React.FC<DiagnosticExpressProps> = ({ onOpenBooking }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  const currentQ = AUDIT_QUESTIONS[currentQuestionIndex];

  const handleSelectOption = (score: number) => {
    const newAnswers = { ...userAnswers, [currentQ.id]: score };
    setUserAnswers(newAnswers);

    if (currentQuestionIndex < AUDIT_QUESTIONS.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setIsCompleted(true);
    }
  };

  const handleReset = () => {
    setUserAnswers({});
    setCurrentQuestionIndex(0);
    setIsCompleted(false);
  };

  // Compute total score out of 100
  const totalScore = Object.values(userAnswers).reduce((acc, curr) => acc + curr, 0);

  const getEvaluation = (score: number) => {
    if (score >= 80) {
      return {
        level: "Niveau de Sécurité Élevé",
        color: "text-emerald-700 bg-emerald-50 border-emerald-200",
        icon: ShieldCheck,
        summary: "Vos pratiques fondamentales sont globalement bien encadrées. Une veille conventionnelle régulière vous permettra de maintenir ce niveau d'excellence face aux réformes.",
        recommendation: "Un abonnement de veille & hotline juridique pour sécuriser vos situations ponctuelles."
      };
    } else if (score >= 50) {
      return {
        level: "Zone de Vigilance Juridique",
        color: "text-amber-800 bg-amber-50 border-amber-200",
        icon: AlertTriangle,
        summary: "Votre entreprise présente des zones d'ombre réglementaires (DUERP, entretiens ou contrats). En cas de contrôle de l'inspection ou de conflit individuel, ces failles peuvent vous fragiliser.",
        recommendation: "Un audit de conformité 360° pour mettre à jour vos modèles et documents obligatoires."
      };
    } else {
      return {
        level: "Vulnérabilité Juridique Critique",
        color: "text-red-700 bg-red-50 border-red-200",
        icon: ShieldAlert,
        summary: "Plusieurs obligations légales majeures ne sont pas sécurisées. Le risque de contentieux prud'homal lourd ou de sanctions administratives est immédiat.",
        recommendation: "Un diagnostic d'urgence et la mise en place d'un accompagnement RH opérationnel sous 48h."
      };
    }
  };

  const evalResult = getEvaluation(totalScore);
  const EvalIcon = evalResult.icon;

  return (
    <section id="audit-express" className="py-20 bg-[#F4F5F7] border-b border-neutral-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 tracking-wide uppercase mb-2">
            <span>Outil Dirigeant Gratuit</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="text-slate-500 font-normal normal-case">2 minutes</span>
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Évaluez le Niveau de Risque RH de votre Entreprise
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            5 questions clés pour tester la conformité juridique et l'organisation RH de votre TPE/PME.
          </p>
        </div>

        {/* Audit Container */}
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-md p-6 sm:p-10">
          
          {!isCompleted ? (
            <div>
              {/* Progress Bar */}
              <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
                <span className="font-semibold text-slate-900">
                  Question {currentQuestionIndex + 1} sur {AUDIT_QUESTIONS.length}
                </span>
                <span className="font-mono">
                  {Math.round(((currentQuestionIndex) / AUDIT_QUESTIONS.length) * 100)}% complété
                </span>
              </div>
              <div className="h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden mb-8">
                <div 
                  className="h-full bg-slate-900 rounded-full transition-all duration-300"
                  style={{ width: `${((currentQuestionIndex + 1) / AUDIT_QUESTIONS.length) * 100}%` }}
                />
              </div>

              {/* Current Question */}
              <div className="space-y-4 mb-8">
                <h3 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
                  {currentQ.question}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 bg-neutral-50 p-3 rounded-lg border border-neutral-100">
                  <span className="font-semibold text-slate-700">Pourquoi c'est crucial :</span> {currentQ.context}
                </p>
              </div>

              {/* Options */}
              <div className="space-y-3">
                {currentQ.options.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(opt.score)}
                    className="w-full text-left p-4 rounded-xl border border-neutral-200 hover:border-slate-900 hover:bg-neutral-50/70 transition-all flex items-start gap-3 group cursor-pointer"
                  >
                    <div className="w-5 h-5 rounded-full border border-neutral-300 flex items-center justify-center shrink-0 mt-0.5 group-hover:border-slate-900 group-hover:bg-slate-900 group-hover:text-white transition-all text-[11px] font-bold">
                      {String.fromCharCode(65 + idx)}
                    </div>
                    <div className="flex-1">
                      <span className="text-sm font-semibold text-slate-800 block group-hover:text-slate-900">
                        {opt.label}
                      </span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Back / Skip navigation */}
              <div className="mt-8 pt-4 border-t border-neutral-100 flex items-center justify-between text-xs text-slate-500">
                {currentQuestionIndex > 0 ? (
                  <button
                    onClick={() => setCurrentQuestionIndex(currentQuestionIndex - 1)}
                    className="hover:text-slate-900 cursor-pointer"
                  >
                    &larr; Question précédente
                  </button>
                ) : (
                  <span />
                )}
                <span>Réponse confidentielle</span>
              </div>
            </div>
          ) : (
            /* Results Screen */
            <div className="space-y-6">
              <div className="text-center space-y-3 pb-6 border-b border-neutral-100">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-900 text-amber-300 mx-auto shadow-md">
                  <EvalIcon className="w-8 h-8" />
                </div>
                <div>
                  <span className="text-xs uppercase font-bold tracking-widest text-slate-400">
                    Résultat de votre diagnostic RH
                  </span>
                  <div className="text-4xl sm:text-5xl font-extrabold text-slate-900 font-display tabular-nums mt-1">
                    {totalScore} / 100
                  </div>
                </div>
                <div className={`inline-block px-3.5 py-1 rounded-full text-xs font-bold border ${evalResult.color}`}>
                  {evalResult.level}
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Analyse de vos réponses :
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {evalResult.summary}
                  </p>
                </div>

                <div className="bg-amber-50/70 rounded-xl p-4 border border-amber-200/60">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900 mb-1">
                    Recommandation prioritaire d'Auréalys Conseil RH :
                  </h4>
                  <p className="text-xs sm:text-sm text-amber-950 font-medium leading-relaxed">
                    {evalResult.recommendation}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-4 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => onOpenBooking(`Diagnostic Risques RH - Score ${totalScore}/100 (${evalResult.level})`)}
                  className="flex-1 py-3.5 px-6 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Débriefer mon score gratuitement avec Mathilde (30 min)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={handleReset}
                  className="py-3.5 px-4 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-slate-700 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Recommencer</span>
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </section>
  );
};
