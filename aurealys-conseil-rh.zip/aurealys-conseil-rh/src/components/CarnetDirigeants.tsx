import React, { useState } from 'react';
import { BookOpen, Download, CheckCircle2, ArrowRight, Sparkles, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

export const CarnetDirigeants: React.FC = () => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [downloaded, setDownloaded] = useState(false);
  const [error, setError] = useState('');

  const handleDownload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      setError('Veuillez renseigner une adresse email professionnelle valide.');
      return;
    }
    setError('');
    setDownloaded(true);
  };

  return (
    <section className="py-20 bg-[#FAF8F5] border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="bg-white rounded-3xl border border-neutral-200 shadow-xl overflow-hidden p-8 sm:p-12 lg:p-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            
            {/* Left: Book Cover Image & Badge (5 cols) */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <div className="relative max-w-xs sm:max-w-sm w-full group">
                <div className="aspect-[3/4] rounded-2xl overflow-hidden border border-neutral-200 shadow-2xl bg-neutral-100 relative">
                  <img
                    src="/src/assets/images/carnet_des_dirigeants_ebook_1792405362246.jpg"
                    alt="Le Carnet des Dirigeants - Pratiques RH Essentielles par Mathilde Galland"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                    loading="lazy"
                  />
                </div>

                <div className="absolute -top-3 -right-3 bg-slate-900 text-amber-300 px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider shadow-lg flex items-center gap-1.5 border border-amber-300/30">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Ebook Offert</span>
                </div>
              </div>

              <div className="mt-4 text-center">
                <span className="text-xs font-medium text-slate-500">
                  Édition réservée aux chefs d'entreprise et dirigeants de PME
                </span>
              </div>
            </div>

            {/* Right: Pitch, Quote & Instant Download Form (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-amber-900 tracking-wide uppercase">
                  <BookOpen className="w-3.5 h-3.5 text-amber-700" />
                  <span>Ressource Exclusive · Auréalys Conseil RH</span>
                </div>
                <h3 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tracking-tight">
                  Le Carnet des Dirigeants
                </h3>
                <span className="text-base font-semibold text-amber-800 block">
                  Pratiques RH Essentielles pour TPE & PME
                </span>
              </div>

              {/* Mathilde's exact signature quote */}
              <blockquote className="bg-[#FAF9F5] p-5 rounded-2xl border-l-4 border-amber-600/70 text-slate-800 text-sm sm:text-base italic leading-relaxed">
                « Le droit du travail n'est pas réservé aux grands groupes. Ce n'est pas une question de taille. C'est une question de méthode. Sécuriser, ce n'est pas tout verrouiller. C'est poser des fondations silencieuses. »
                <span className="block not-italic text-xs font-bold text-slate-900 mt-2">
                  — Mathilde Galland
                </span>
              </blockquote>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Recevez gratuitement ce guide pratique condensé : les 7 erreurs juridiques les plus coûteuses à éviter, la check-list des affichages obligatoires et le canevas de traçabilité managériale pour prévenir tout contentieux prud'homal.
              </p>

              {/* Download Form */}
              {!downloaded ? (
                <form onSubmit={handleDownload} className="space-y-3 pt-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input
                      type="text"
                      placeholder="Votre Prénom et Nom *"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="text-xs p-3 rounded-lg border border-neutral-300 bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900"
                      required
                    />
                    <input
                      type="text"
                      placeholder="Nom de votre entreprise"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      className="text-xs p-3 rounded-lg border border-neutral-300 bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900"
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2.5">
                    <input
                      type="email"
                      placeholder="Votre adresse email professionnelle *"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="text-xs p-3 rounded-lg border border-neutral-300 bg-[#FCFCFA] focus:outline-none focus:ring-1 focus:ring-slate-900 flex-1"
                      required
                    />
                    <button
                      type="submit"
                      className="px-6 py-3 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0"
                    >
                      <Download className="w-4 h-4" />
                      <span>Télécharger mon guide offert</span>
                    </button>
                  </div>

                  {error && <p className="text-xs text-red-600">{error}</p>}

                  <p className="text-[11px] text-slate-400">
                    Envoi instantané · 100% gratuit · Zéro spam, désinscription en 1 clic
                  </p>
                </form>
              ) : (
                <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 space-y-3">
                  <div className="flex items-center gap-2 text-emerald-800 font-bold text-base font-display">
                    <CheckCircle2 className="w-5 h-5 text-emerald-700" />
                    <span>Votre Carnet des Dirigeants est en route !</span>
                  </div>
                  <p className="text-xs text-emerald-900 leading-relaxed">
                    Merci {name || 'cher dirigeant'}, nous venons de vous transmettre l'accès complet au guide à l'adresse <strong>{email}</strong>.
                  </p>
                  <div className="pt-1">
                    <a
                      href="#audit-express"
                      className="text-xs font-bold text-emerald-800 underline hover:text-emerald-950 inline-flex items-center gap-1"
                    >
                      <span>En attendant, évaluez votre score de risque RH en 2 minutes &rarr;</span>
                    </a>
                  </div>
                </div>
              )}

            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
