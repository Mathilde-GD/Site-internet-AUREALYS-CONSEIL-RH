/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProofStrip } from './components/ProofStrip';
import { DualExpertise } from './components/DualExpertise';
import { CustomerJourney } from './components/CustomerJourney';
import { PodcastSection } from './components/PodcastSection';
import { ServicesBento } from './components/ServicesBento';
import { DiagnosticExpress } from './components/DiagnosticExpress';
import { PackagesSection } from './components/PackagesSection';
import { AboutMathilde } from './components/AboutMathilde';
import { CarnetDirigeants } from './components/CarnetDirigeants';
import { Testimonials } from './components/Testimonials';
import { FAQSection } from './components/FAQSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { Calendar, Phone } from 'lucide-react';
import { COMPANY_INFO } from './data/content';

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingTopic, setBookingTopic] = useState<string>('');

  const handleOpenBooking = (topic?: string) => {
    setBookingTopic(topic || 'Diagnostic RH Offert (30 min)');
    setIsBookingOpen(true);
  };

  const handleCloseBooking = () => {
    setIsBookingOpen(false);
    setBookingTopic('');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FCFCFA] text-[#1E293B]">
      
      {/* Top Bar Navigation */}
      <Navbar onOpenBooking={handleOpenBooking} />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero with value proposition & direct CTA */}
        <Hero onOpenBooking={handleOpenBooking} />

        {/* 2. Proof metrics adjacent to claims */}
        <ProofStrip />

        {/* 3. Dual Expertise (Droit Social & Opérationnel RH) */}
        <DualExpertise onOpenBooking={handleOpenBooking} />

        {/* 4. Customer Journey in 4 clear steps for prospects */}
        <CustomerJourney onOpenBooking={handleOpenBooking} />

        {/* 5. Podcast "Le Bureau et la Loi" & YouTube Channel */}
        <PodcastSection onOpenBooking={handleOpenBooking} />

        {/* 6. Core Services Bento Grid */}
        <ServicesBento onOpenBooking={handleOpenBooking} />

        {/* 7. Interactive Diagnostic RH Express */}
        <DiagnosticExpress onOpenBooking={handleOpenBooking} />

        {/* 8. Packages & Accompagnements */}
        <PackagesSection onOpenBooking={handleOpenBooking} />

        {/* 9. About Mathilde Galland */}
        <AboutMathilde onOpenBooking={() => handleOpenBooking("Rencontre avec Mathilde")} />

        {/* 10. Le Carnet des Dirigeants (Ebook Offert) */}
        <CarnetDirigeants />

        {/* 11. Client Testimonials */}
        <Testimonials />

        {/* 11. FAQ */}
        <FAQSection onOpenBooking={() => handleOpenBooking("Question préalable")} />

        {/* 12. Contact & Access */}
        <ContactSection onOpenBooking={() => handleOpenBooking("Prise de contact directe")} />
      </main>

      {/* Footer */}
      <Footer onOpenBooking={() => handleOpenBooking("Prise de contact via footer")} />

      {/* Fully Functional Booking Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={handleCloseBooking}
        initialTopic={bookingTopic}
      />

      {/* Floating Quick Action CTA for mobile/desktop (subtle, non-intrusive) */}
      <aside aria-label="Action rapide de contact" className="fixed bottom-5 right-5 z-30 flex items-center gap-2">
        <a
          href={`tel:${COMPANY_INFO.phoneRaw}`}
          className="hidden sm:flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-white border border-neutral-300 text-slate-800 text-xs font-semibold shadow-lg hover:bg-neutral-50 transition-transform active:scale-95"
          title="Appel direct"
        >
          <Phone className="w-3.5 h-3.5 text-slate-700" />
          <span>{COMPANY_INFO.phoneDisplay}</span>
        </a>

        <button
          onClick={() => handleOpenBooking("Diagnostic RH Offert (30 min)")}
          className="flex items-center gap-2 px-4 py-3 rounded-full bg-slate-900 text-white text-xs font-semibold shadow-xl hover:bg-slate-800 transition-transform active:scale-95 cursor-pointer ring-2 ring-white/50"
          aria-label="Prendre rendez-vous avec Mathilde"
        >
          <Calendar className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">Prendre RdV</span>
          <span className="sm:hidden">RdV Offert</span>
        </button>
      </aside>

    </div>
  );
}
