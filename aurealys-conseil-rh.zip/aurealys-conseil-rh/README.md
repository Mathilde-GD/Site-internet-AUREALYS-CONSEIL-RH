# Auréalys Conseil RH · Plateforme Web & Conseils RH / Droit Social

Site web officiel et plateforme de conversion pour **Auréalys Conseil RH**, cabinet de conseil en ressources humaines et droit social pour les dirigeants de TPE et PME, fondé par **Mathilde Galland**.

---

## 🌟 Fonctionnalités Principales

- **Double Expertise** : Présentation claire de la rigueur du Droit Social et de l'agilité du RH Opérationnel de terrain (spécialisation multi-sites et multi-conventionnelle).
- **Parcours Client en 4 Étapes** : Diagnostic offert, proposition sous 24-48h, action opérationnelle et hotline dirigeant pérenne.
- **Les 3 Offres Claires** :
  - **Le Pack Essentiel** : Pour TPE (1 à 12 salariés), hotline sous 24h ouvrées et relecture de contrats types.
  - **Le Pack Pilotage** : Formule la plus plébiscitée (10 à 35 salariés), gestion intégrale des ruptures, sanctions, et point mensuel de direction.
  - **Le Pack Premium** : Direction RH en temps partagé sur site (1 à 2 jours / mois) pour structures multi-sites et multi-CCN.
- **Podcast « Le Bureau et la Loi » & Chaîne YouTube** : Lecteur d'extraits, fiche du dernier épisode (*« Le contentieux qui naît d'une performance jamais formalisée »*) et liens d'abonnement.
- **Auto-Diagnostic Risques RH Express (2 min)** : Outil interactif calculant un score de conformité sur 100 avec recommandations personnalisées.
- **« Le Carnet des Dirigeants »** : Lead magnet avec formulaire de téléchargement instantané pour chefs d'entreprise.
- **Prise de Rendez-vous 100% Opérationnelle** : Module de réservation de diagnostic RH (30 min) avec sélection de créneaux et export vers **Google Calendar** et fichier **.ics** (Outlook, Apple Calendar).
- **Mentions Légales, CGV & RGPD** : Panneau modal complet conforme au droit français.

---

## 🚀 Installation & Développement Local

```bash
# Cloner le dépôt
git clone https://github.com/VOTRE_NOM_UTILISATEUR/aurealys-conseil-rh.git

# Installer les dépendances
npm install

# Lancer le serveur de développement local
npm run dev

# Compiler pour la production
npm run build
```

---

## 📦 Déploiement en 1 Clic (depuis GitHub)

Ce projet est prêt pour un déploiement instantané et gratuit sur :
1. **Vercel** : Connectez votre compte GitHub, sélectionnez le dépôt, et cliquez sur **Deploy**.
2. **Netlify** : Choisissez **Import from Git**, sélectionnez le projet (commande de build : `npm run build`, dossier : `dist`).
3. **Cloudflare Pages** : Connectez le dépôt GitHub (framework preset: Vite).

---

## 📞 Coordonnées

- **Cabinet** : Auréalys Conseil RH
- **Adresse** : 270 allée des Lilas, 01150 Saint-Vulbas (PIPA · Auvergne-Rhône-Alpes)
- **Téléphone** : 07 63 43 43 78
- **Email** : contact@aurealysconseilrh.fr
- **Fondatrice** : Mathilde Galland
